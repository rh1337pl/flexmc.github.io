export type GameServerType = 'anarchy' | 'skyblock' | 'pvp';

export interface ServerStatusInfo {
  id: GameServerType;
  name: string;
  online: boolean;
  playersCount: number;
  maxPlayers: number;
  version: string;
  ping: number;
  description: string;
  uptime: string;
  hardware: string;
  voicePluginRequired: boolean;
}

export interface RuleInfo {
  id: string;
  title: string;
  description: string;
  severity: 'high' | 'medium' | 'low';
}

export interface FeatureInfo {
  title: string;
  description: string;
  iconName: string; // references standard Lucide icons
}

export interface RankPerk {
  name: string;
  price: string;
  color: string;
  perks: string[];
  multiplier: string;
}

export interface LeaderboardEntry {
  position: number;
  username: string;
  skinSeed: string; // for custom avatars or coloring
  statValue: string;
  extraStatLabel?: string;
  extraStatValue?: string;
  tag?: string; // e.g. [VIP], [MVP], [HEALER]
}

export interface LeaderboardCollection {
  anarchy: LeaderboardEntry[];
  skyblock: LeaderboardEntry[];
  pvp: LeaderboardEntry[];
}

export interface StoreItem {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  category: 'ranks' | 'keys' | 'boosters' | 'cosmetics';
  description: string;
  features: string[];
  badge?: string; // "Hot", "Sale", "Popular"
  color: string; // custom classes or hex values for visual flair
}

export interface NewsArticle {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  author: string;
  category: 'Update' | 'Event' | 'Community' | 'System';
  readTime: string;
  image: string;
}

export interface ChatMessage {
  id: string;
  timestamp: string;
  username: string;
  prefix?: string;
  prefixColor?: string;
  message: string;
  server: GameServerType | 'hub';
}
