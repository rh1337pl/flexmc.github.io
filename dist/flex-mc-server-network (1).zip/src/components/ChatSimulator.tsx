import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, MessageSquare, Terminal, Users, Sparkles } from 'lucide-react';
import { MOCK_CHAT_POOL } from '../data/serverData';
import { ChatMessage } from '../types';

export default function ChatSimulator() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '1', timestamp: '20:25', username: 'FitMC_Enthusiast', message: 'Anyone around spawn coordinates?', prefix: '[DOOM]', prefixColor: 'text-purple-500', server: 'anarchy' },
    { id: '2', timestamp: '20:26', username: 'DrSeedPlanter', message: 'WTS automatic wood minion at my island warp pv 1', prefix: '[ASTRAL]', prefixColor: 'text-cyan-400', server: 'skyblock' },
    { id: '3', timestamp: '20:28', username: 'System_Daemon', message: 'Tournament registrations are now open for Saturday 2v2 PvP matches!', prefix: '[ANNOUNCEMENT]', prefixColor: 'text-yellow-500', server: 'pvp' }
  ]);
  const [inputText, setInputText] = useState('');
  const [currentNickname, setCurrentNickname] = useState('');
  const [activeRoom, setActiveRoom] = useState<'all' | 'anarchy' | 'skyblock' | 'pvp'>('all');
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Periodic simulated chat appended
  useEffect(() => {
    const chatInterval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * MOCK_CHAT_POOL.length);
      const randomChat = MOCK_CHAT_POOL[randomIndex];
      const servers: ('anarchy' | 'skyblock' | 'pvp')[] = ['anarchy', 'skyblock', 'pvp'];
      const randomServer = servers[Math.floor(Math.random() * servers.length)];
      
      const newMsg: ChatMessage = {
        id: Date.now().toString(),
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' }),
        username: randomChat.username,
        prefix: randomChat.prefix || undefined,
        prefixColor: randomChat.prefixColor || undefined,
        message: randomChat.message,
        server: randomServer
      };

      setMessages(prev => [...prev.slice(-30), newMsg]);
    }, 6000);

    return () => clearInterval(chatInterval);
  }, []);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const myNick = currentNickname.trim() || 'Excited_Gamer';
    const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });
    
    const guestMsg: ChatMessage = {
      id: Date.now().toString(),
      timestamp,
      username: myNick,
      prefix: '[GUEST]',
      prefixColor: 'text-gray-400',
      message: inputText,
      server: activeRoom === 'all' ? 'anarchy' : activeRoom
    };

    setMessages(prev => [...prev, guestMsg]);
    setInputText('');

    // Trigger funny Minecraft bot replies 
    setTimeout(() => {
      const replies = [
        `Gg ${myNick}! Are you playing on PvP practice right now?`,
        `Nice message ${myNick}, join Discord to use 3D proximity chat together.`,
        `Welcome to the Flex-MC chat stream! Use IP Flex-MC.eu to connect.`,
        `Is anyone looking to build a base?`,
      ];
      const botReply: ChatMessage = {
        id: (Date.now() + 1).toString(),
        timestamp,
        username: 'Bot_Guard',
        prefix: '[CO-MOD]',
        prefixColor: 'text-amber-500',
        message: replies[Math.floor(Math.random() * replies.length)],
        server: guestMsg.server
      };
      setMessages(prev => [...prev, botReply]);
    }, 1500);
  };

  const filteredMessages = messages.filter(msg => {
    if (activeRoom === 'all') return true;
    return msg.server === activeRoom;
  });

  return (
    <div className="bg-slate-950/80 rounded-2xl border border-slate-900 overflow-hidden shadow-2xl flex flex-col h-[520px]">
      
      {/* Header bar of Live Feed */}
      <div className="px-5 py-4 bg-slate-900/60 border-b border-slate-900/80 flex flex-wrap gap-3 items-center justify-between">
        <div className="flex items-center gap-2">
          <Terminal className="text-yellow-500 w-4 h-4" />
          <h3 className="font-pixel text-[11px] tracking-wider text-white">Live Server Chat</h3>
          <div className="px-2 py-0.5 rounded bg-emerald-500/10 text-[9px] font-mono text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span>LIVE SYNC</span>
          </div>
        </div>

        {/* Room select */}
        <div className="flex gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-900">
          {(['all', 'anarchy', 'skyblock', 'pvp'] as const).map(room => (
            <button
              key={room}
              onClick={() => setActiveRoom(room)}
              className={`px-3 py-1 rounded-md text-xs font-mono capitalize transition-all cursor-pointer ${
                activeRoom === room 
                  ? 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/30 font-semibold' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              {room}
            </button>
          ))}
        </div>
      </div>

      {/* Main chatting scrolling window */}
      <div className="flex-1 p-5 overflow-y-auto space-y-3.5 bg-slate-950/30 font-mono text-[13px]">
        <AnimatePresence initial={false}>
          {filteredMessages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="group flex items-start gap-2.5 leading-relaxed hover:bg-slate-900/20 px-2 py-1 rounded transition-colors"
            >
              {/* Timestamp */}
              <span className="text-slate-600 text-[11px] select-none mt-0.5">{msg.timestamp}</span>

              {/* Room Badge */}
              <span className={`text-[9px] px-1 py-0.2 rounded border uppercase select-none ${
                msg.server === 'anarchy' ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' :
                msg.server === 'skyblock' ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20' :
                msg.server === 'pvp' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                'bg-slate-800 text-slate-400 border-slate-700'
              }`}>
                {msg.server}
              </span>

              {/* Username block */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {msg.prefix && (
                  <span className={`text-[10px] font-bold ${msg.prefixColor || 'text-slate-400'}`}>
                    {msg.prefix}
                  </span>
                )}
                <span className="text-slate-200 font-bold hover:underline cursor-pointer">
                  {msg.username}
                </span>
                <span className="text-slate-500">:</span>
                <span className="text-slate-300 break-all">{msg.message}</span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        <div ref={chatEndRef} />
      </div>

      {/* Guest chat box controls */}
      <form onSubmit={handleSendMessage} className="p-4 bg-slate-900/40 border-t border-slate-900">
        <div className="flex flex-col sm:flex-row gap-2">
          {/* Mock skin name selection */}
          <input
            type="text"
            placeholder="Minecraft Nickname..."
            value={currentNickname}
            onChange={(e) => setCurrentNickname(e.target.value)}
            className="w-full sm:w-1/3 px-3.5 py-2 rounded-xl bg-slate-950/90 border border-slate-800 text-slate-300 placeholder-slate-600 text-xs focus:ring-1 focus:ring-yellow-500/50 outline-none transition-all font-mono"
            maxLength={16}
          />
          {/* Chat message input */}
          <div className="flex-1 flex gap-2 relative">
            <input
              type="text"
              placeholder="Type message in game chat..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="flex-1 px-3.5 py-2.5 pr-10 rounded-xl bg-slate-950/90 border border-slate-800 text-slate-200 placeholder-slate-500 text-xs focus:ring-1 focus:ring-yellow-500/50 outline-none transition-all font-mono"
              maxLength={100}
            />
            <button
              type="submit"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-yellow-500 active:scale-95 transition-all p-1.5 cursor-pointer rounded-lg hover:bg-slate-900"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        <p className="mt-2 text-[10px] text-slate-600 font-mono text-center sm:text-left">
          Proximity modules connected. Add Simple Voice Chat on CurseForge to speak directly using vocal sound.
        </p>
      </form>
    </div>
  );
}
