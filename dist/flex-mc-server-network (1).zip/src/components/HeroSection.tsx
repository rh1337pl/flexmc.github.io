import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Copy, Check, Users, Wifi, Swords, Shield, Coins, Mic, MessageSquare } from 'lucide-react';
import { SERVER_IP } from '../data/serverData';

interface HeroSectionProps {
  totalPlayers: number;
  onNavigate: (tab: string) => void;
}

export default function HeroSection({ totalPlayers, onNavigate }: HeroSectionProps) {
  const [copied, setCopied] = useState(false);
  const [ticker, setTicker] = useState(0);

  // Smooth local ticker to simulate micro-variance in player count
  useEffect(() => {
    const timer = setInterval(() => {
      setTicker(Math.floor(Math.random() * 9) - 4);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(SERVER_IP);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const displayPlayersCount = Math.max(120, totalPlayers + ticker);

  return (
    <div className="relative min-h-[70vh] flex flex-col justify-center items-center overflow-hidden bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950 px-4 py-16 border-b border-slate-900">
      
      {/* Decorative Minecraft grid/stars pattern */}
      <div 
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(#ca8a04 1px, transparent 1px)`,
          backgroundSize: '24px 24px',
        }}
      />

      {/* Backdrop glowing nebulas */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-yellow-600/10 blur-[130px] rounded-full pointer-events-none" />
      <div className="absolute -bottom-10 right-1/4 w-[300px] h-[300px] bg-red-600/10 blur-[100px] rounded-full pointer-events-none" />

      {/* Floating game status flag */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-slate-800 text-xs text-yellow-500 font-mono tracking-wider mb-6 shadow-xl"
      >
        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        <span>FLEX-MC 1.8 - 1.20+ OPEN FOR PLAY</span>
      </motion.div>

      {/* Main branded headline */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, delay: 0.1 }}
        className="text-center max-w-4xl z-10"
      >
        <span className="text-xs uppercase font-pixel tracking-[0.25em] text-slate-500 mb-2 block">The Ultimate Server Network</span>
        <h1 className="text-5xl md:text-8xl font-black font-sans uppercase tracking-tight bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-600 bg-clip-text text-transparent drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)] leading-[1.1] mb-4">
          FLEX-MC<span className="text-glow-gold">.EU</span>
        </h1>
        <p className="text-base md:text-xl text-slate-400 font-normal max-w-2xl mx-auto leading-relaxed px-2">
          Experience unrivaled competitive gaming on Europe’s finest network. Unleash chaotic combat in our full <span className="text-yellow-500 font-semibold">Anarchy</span> realm, build automated economies in <span className="text-cyan-400 font-semibold">SkyBlock</span>, or duel tactical masters on <span className="text-red-500 font-semibold">PvP Arenas</span>.
        </p>
      </motion.div>

      {/* Interactive Server Copy-IP block */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="mt-10 w-full max-w-lg z-10 flex flex-col sm:flex-row gap-3 items-center justify-center"
      >
        <div 
          onClick={handleCopy}
          className="w-full sm:w-auto flex items-center justify-between gap-4 px-5 py-4 bg-slate-900/90 dark:bg-slate-950/80 hover:bg-slate-900 border border-slate-800 hover:border-yellow-500/50 rounded-xl cursor-pointer transition-all duration-300 md:min-w-[340px] group shadow-2xl relative overflow-hidden"
        >
          {/* Subtle overlay accent */}
          <div className="absolute top-0 left-0 w-1 h-full bg-yellow-500 group-hover:bg-yellow-400 transition-colors" />
          
          <div className="flex flex-col text-left font-mono">
            <span className="text-[10px] uppercase tracking-wider text-slate-500 group-hover:text-yellow-500/80 transition-colors">Server IP Click To Copy</span>
            <span className="text-lg md:text-xl font-bold text-white tracking-wide">{SERVER_IP}</span>
          </div>

          <div className="relative flex justify-center items-center w-10 h-10 rounded-lg bg-slate-800 group-hover:bg-yellow-500/10 border border-slate-700 group-hover:border-yellow-500/30 transition-all">
            <AnimatePresence mode="wait">
              {copied ? (
                <motion.div key="check" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.5, opacity: 0 }} className="text-emerald-400">
                  <Check className="w-5 h-5" />
                </motion.div>
              ) : (
                <motion.div key="copy" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.5, opacity: 0 }} className="text-slate-400 group-hover:text-yellow-500">
                  <Copy className="w-5 h-5" />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <button 
          onClick={() => onNavigate('dashboard')}
          className="w-full sm:w-auto px-7 py-4.5 bg-yellow-500 hover:bg-yellow-400 active:scale-98 text-slate-950 font-bold uppercase tracking-wider rounded-xl cursor-pointer shadow-xl shadow-yellow-500/10 hover:shadow-yellow-500/20 hover:scale-102 transition-all duration-300 text-sm flex items-center justify-center gap-2"
        >
          <span>Explore Servers</span>
          <Swords className="w-4 h-4" />
        </button>
      </motion.div>

      {/* Network stats micro visualizer */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.8 }}
        className="mt-12 flex flex-wrap gap-8 justify-center items-center text-slate-400 z-10"
      >
        <div className="flex items-center gap-3 font-mono text-sm bg-slate-950/40 px-4 py-2 rounded-lg border border-slate-900">
          <Users className="w-4 h-4 text-yellow-500 animate-pulse" />
          <span>Active Players: <strong className="text-white text-base">{displayPlayersCount}</strong></span>
        </div>
        <div className="flex items-center gap-3 font-mono text-sm bg-slate-950/40 px-4 py-2 rounded-lg border border-slate-900">
          <Wifi className="w-4 h-4 text-emerald-500" />
          <span>Average Ping: <strong className="text-white text-base">15ms</strong></span>
        </div>
        <div className="flex items-center gap-3 font-mono text-sm bg-slate-950/40 px-4 py-2 rounded-lg border border-slate-900">
          <Mic className="w-4 h-4 text-cyan-400" />
          <span>Proximity Chat: <strong className="text-white text-base">3D active</strong></span>
        </div>
      </motion.div>

      {/* Interactive notification bubble of copy */}
      <AnimatePresence>
        {copied && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-6 filter drop-shadow bg-emerald-500 text-slate-950 px-5 py-3 rounded-lg flex items-center gap-2.5 font-sans font-bold text-sm tracking-wide z-50 pointer-events-none shadow-2xl"
          >
            <Check className="w-4.5 h-4.5 stroke-[2.5px]" />
            <span>Connection IP copied! Ready to Join {SERVER_IP}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
