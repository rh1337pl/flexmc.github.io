import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Swords, ShieldAlert, Compass, Cpu, UserRound, TrendingUp, 
  LayoutGrid, Coins, Volume2, Zap, Sparkles, ShoppingCart, 
  Home, BookOpen, Heart, Skull, Crown, MessageSquare, Plus, 
  Minus, Trash2, Play, Check, ExternalLink, ChevronRight, Mic, 
  Trophy, Menu, X, Gift, Server, Activity, ArrowRight, Star, 
  Clock, AlertTriangle, MessageCircle, VolumeX, Volume1
} from 'lucide-react';

import HeroSection from './components/HeroSection';
import { 
  SERVERS_INFO, 
  RULES_DATA, 
  FEATURES_DATA, 
  RANK_PERKS, 
  LEADERBOARD_DATA, 
  STORE_ITEMS, 
  NEWS_ARTICLES, 
  VOICE_CHAT_GUIDE, 
  MOCK_CHAT_POOL,
  SERVER_IP 
} from './data/serverData';
import { GameServerType, StoreItem, NewsArticle, ChatMessage } from './types';

export default function App() {
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<'dashboard' | 'store' | 'discord' | 'wiki'>('dashboard');
  
  // Dashboard states
  const [selectedServer, setSelectedServer] = useState<GameServerType>('anarchy');

  // Interactive Live Chat stream state
  const [chatFeed, setChatFeed] = useState<ChatMessage[]>([]);
  const [userChatMessage, setUserChatMessage] = useState('');
  const [userNickname, setUserNickname] = useState('');
  const [selectedChatServer, setSelectedChatServer] = useState<GameServerType | 'hub'>('hub');

  // Read more modal for News
  const [selectedNews, setSelectedNews] = useState<NewsArticle | null>(null);

  // Store and Cart States
  const [storeCategory, setStoreCategory] = useState<'all' | 'ranks' | 'keys' | 'boosters' | 'cosmetics'>('all');
  const [cart, setCart] = useState<{ item: StoreItem; quantity: number }[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [minecraftUsername, setMinecraftUsername] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal' | 'crypto'>('card');
  const [checkoutStep, setCheckoutStep] = useState<'shopping' | 'processing' | 'success'>('shopping');

  // Interactive Audio Simulator States
  const [soundRadarDistance, setSoundRadarDistance] = useState(60); // 0 to 100 distance from mic
  const [isAudioTesting, setIsAudioTesting] = useState(false);
  const audioTickerRef = useRef<number | null>(null);
  const [voiceVolumeScale, setVoiceVolumeScale] = useState(100);

  // Client Verification Tool State
  const [verifyName, setVerifyName] = useState('');
  const [verifyStatus, setVerifyStatus] = useState<'idle' | 'testing' | 'success' | 'failed'>('idle');
  const [verifyStepText, setVerifyStepText] = useState('');

  // Mobile Menu State
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Auto incremental player lists & dynamic stats
  const totalPlayersOnline = useMemo(() => {
    return Object.values(SERVERS_INFO).reduce((acc, curr) => acc + curr.playersCount, 0);
  }, []);

  // Pre-fill initial chats on load and simulate new ones coming in
  useEffect(() => {
    // Generate initial server-appropriate chats
    const initialChats: ChatMessage[] = MOCK_CHAT_POOL.map((chat, i) => ({
      id: `init-${i}`,
      timestamp: new Date(Date.now() - (7 - i) * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      username: chat.username,
      prefix: chat.prefix || undefined,
      prefixColor: chat.prefixColor || undefined,
      message: chat.message,
      server: (['anarchy', 'skyblock', 'pvp'] as GameServerType[])[i % 3] as GameServerType
    }));
    setChatFeed(initialChats);

    // Simulate real game chats rolling in
    const chatInterval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * MOCK_CHAT_POOL.length);
      const randomChat = MOCK_CHAT_POOL[randomIndex];
      const servers: (GameServerType | 'hub')[] = ['anarchy', 'skyblock', 'pvp', 'hub'];
      const randomServ = servers[Math.floor(Math.random() * servers.length)];
      
      const newMsg: ChatMessage = {
        id: `live-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        username: randomChat.username,
        prefix: randomChat.prefix || undefined,
        prefixColor: randomChat.prefixColor || undefined,
        message: randomChat.message,
        server: randomServ as any
      };

      setChatFeed(prev => [...prev.slice(-14), newMsg]);
    }, 8000);

    return () => clearInterval(chatInterval);
  }, []);

  // Proximity sound pulse effect animation
  useEffect(() => {
    if (isAudioTesting) {
      const interval = setInterval(() => {
        setVoiceVolumeScale(prev => {
          // Calculate sound attenuation based on distance
          const attenuation = Math.max(0, 100 - soundRadarDistance);
          // Add minor flutter/vibrancy to simulate voice fluctuations
          const flutter = Math.sin(Date.now() / 150) * 8;
          return Math.max(0, Math.min(100, attenuation + flutter));
        });
      }, 100);
      return () => clearInterval(interval);
    }
  }, [isAudioTesting, soundRadarDistance]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userChatMessage.trim()) return;

    const nick = userNickname.trim() || 'GuestPvper';
    const newMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      username: nick,
      prefix: '[PLAYER]',
      prefixColor: 'text-amber-500',
      message: userChatMessage,
      server: selectedChatServer
    };

    setChatFeed(prev => [...prev, newMsg]);
    setUserChatMessage('');
  };

  const handleVerifyName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyName.trim()) return;

    setVerifyStatus('testing');
    setVerifyStepText('Handshaking with ' + SERVER_IP + ' login proxy...');

    setTimeout(() => {
      setVerifyStepText('Scanning live network socket for block player "' + verifyName + '"...');
      setTimeout(() => {
        setVerifyStepText('Validating UUID and scanning client JVM system for simple-voice mod jar...');
        setTimeout(() => {
          setVerifyStatus('success');
          setVerifyStepText('Link Verified! Simple Voice Chat (v1.20) discovered running correctly in game container.');
        }, 1500);
      }, 1500);
    }, 1200);
  };

  // Cart operations
  const addToCart = (item: StoreItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.item.id === item.id);
      if (existing) {
        return prev.map(i => i.item.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { item, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.item.id === id) {
        const newQty = i.quantity + delta;
        return newQty > 0 ? { ...i, quantity: newQty } : i;
      }
      return i;
    }).filter(i => i.quantity > 0));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(i => i.item.id !== id));
  };

  const cartTotal = useMemo(() => {
    return cart.reduce((sum, current) => sum + (current.item.price * current.quantity), 0);
  }, [cart]);

  const executeCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!minecraftUsername.trim()) return;

    setCheckoutStep('processing');
    setTimeout(() => {
      setCheckoutStep('success');
      setCart([]);
    }, 2500);
  };

  const navigateTo = (tab: 'dashboard' | 'store' | 'discord' | 'wiki') => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setIsMobileMenuOpen(false);
  };

  const filteredStoreItems = useMemo(() => {
    if (storeCategory === 'all') return STORE_ITEMS;
    return STORE_ITEMS.filter(item => item.category === storeCategory);
  }, [storeCategory]);

  return (
    <div className="min-h-screen bg-[#050506] text-zinc-100 font-sans flex flex-col relative">
      
      {/* Background radial atmosphere */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-[20%] -left-[10%] w-[65%] h-[65%] bg-purple-950/15 rounded-full blur-[140px]" />
        <div className="absolute -bottom-[20%] -right-[10%] w-[65%] h-[65%] bg-blue-950/15 rounded-full blur-[140px]" />
        <div className="absolute top-[40%] left-[30%] w-[50%] h-[50%] bg-amber-950/5 rounded-full blur-[160px]" />
      </div>

      {/* HEADER NAVBAR */}
      <header className="sticky top-0 h-18 bg-[#07070a]/90 backdrop-blur-md border-b border-white/5 z-40 flex items-center justify-between px-4 md:px-8">
        
        {/* Brand Logo */}
        <div className="flex items-center gap-3 cursor-pointer group" onClick={() => navigateTo('dashboard')}>
          <div className="w-10 h-10 bg-gradient-to-br from-yellow-500 via-amber-600 to-amber-700 rounded-xl flex items-center justify-center shadow-lg shadow-amber-500/10 group-hover:scale-105 transition-transform">
            <span className="font-pixel font-black text-lg text-slate-950">F</span>
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-extrabold tracking-tight text-white group-hover:text-yellow-400 transition-colors">FLEX-MC<span className="text-yellow-500">.EU</span></span>
            <span className="text-[9px] text-zinc-500 uppercase tracking-[0.25em] font-semibold">Ultimate Premium Network</span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex gap-8 items-center text-xs font-bold uppercase tracking-widest">
          <button 
            onClick={() => navigateTo('dashboard')} 
            className={`cursor-pointer transition-colors py-1 px-2.5 rounded ${activeTab === 'dashboard' ? 'text-yellow-500 bg-yellow-500/5 border-b-2 border-yellow-500' : 'text-zinc-400 hover:text-white'}`}
          >
            DASHBOARD
          </button>
          <button 
            onClick={() => navigateTo('store')} 
            className={`cursor-pointer transition-colors py-1 px-2.5 rounded ${activeTab === 'store' ? 'text-yellow-500 bg-yellow-500/5 border-b-2 border-yellow-500' : 'text-zinc-400 hover:text-white'}`}
          >
            STORE
          </button>
          <button 
            onClick={() => navigateTo('discord')} 
            className={`cursor-pointer transition-colors py-1 px-2.5 rounded ${activeTab === 'discord' ? 'text-yellow-500 bg-yellow-500/5 border-b-2 border-yellow-500' : 'text-zinc-400 hover:text-white'}`}
          >
            DISCORD COMMUNITY
          </button>
          <button 
            onClick={() => navigateTo('wiki')} 
            className={`cursor-pointer transition-colors py-1 px-2.5 rounded ${activeTab === 'wiki' ? 'text-yellow-500 bg-yellow-500/5 border-b-2 border-yellow-500' : 'text-zinc-400 hover:text-white'}`}
          >
            WIKI & GUIDES
          </button>
        </nav>

        {/* Status indicator and actions */}
        <div className="hidden md:flex items-center gap-4">
          
          {/* Global Network Live Counter */}
          <div className="flex items-center gap-2 bg-zinc-950/65 px-4 py-2 border border-white/5 rounded-xl text-xs font-mono font-bold tracking-wide shadow-xl">
            <div className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
            </div>
            <span className="text-zinc-400">ONLINE PLAYERS:</span>
            <span className="text-emerald-400">{totalPlayersOnline}</span>
          </div>

          {/* Cart Icon */}
          <button 
            onClick={() => setIsCartOpen(true)}
            className="p-2.5 bg-zinc-900 border border-white/5 hover:border-zinc-700 hover:bg-zinc-800 rounded-xl transition-all text-zinc-400 hover:text-white cursor-pointer relative"
          >
            <ShoppingCart className="w-5 h-5" />
            {cart.length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-yellow-500 text-slate-950 text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center animate-bounce shadow">
                {cart.reduce((s, c) => s + c.quantity, 0)}
              </span>
            )}
          </button>

          {/* Discord Launch CTA Button */}
          <button 
            onClick={() => navigateTo('discord')}
            className="bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs tracking-wider uppercase transition-colors shadow-lg shadow-yellow-500/10 cursor-pointer"
          >
            Community Discord
          </button>
        </div>

        {/* Mobile controls */}
        <div className="flex md:hidden items-center gap-2">
          {/* Mobile Cart Trigger */}
          <button 
            onClick={() => setIsCartOpen(true)}
            className="p-2.5 bg-zinc-900 border border-white/5 rounded-lg text-zinc-400 relative"
          >
            <ShoppingCart className="w-5 h-5" />
            {cart.length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-yellow-500 text-slate-950 text-[9px] font-extrabold w-4.5 h-4.5 rounded-full flex items-center justify-center">
                {cart.length}
              </span>
            )}
          </button>

          {/* Mobile Nav toggle */}
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
            className="p-2.5 bg-zinc-900 border border-white/5 rounded-lg text-zinc-400 cursor-pointer"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </header>

      {/* MOBILE NAV DRAWER */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-[#07070a] border-b border-white/5 z-35 flex flex-col px-4 py-6 gap-4"
          >
            <div className="flex flex-col gap-2">
              <button 
                onClick={() => navigateTo('dashboard')} 
                className={`py-3 px-4 rounded text-left font-bold ${activeTab === 'dashboard' ? 'bg-yellow-500/10 text-yellow-500' : 'text-zinc-400'}`}
              >
                DASHBOARD
              </button>
              <button 
                onClick={() => navigateTo('store')} 
                className={`py-3 px-4 rounded text-left font-bold ${activeTab === 'store' ? 'bg-yellow-500/10 text-yellow-500' : 'text-zinc-400'}`}
              >
                STORE
              </button>
              <button 
                onClick={() => navigateTo('discord')} 
                className={`py-3 px-4 rounded text-left font-bold ${activeTab === 'discord' ? 'bg-yellow-500/10 text-yellow-500' : 'text-zinc-400'}`}
              >
                DISCORD COMMUNITY
              </button>
              <button 
                onClick={() => navigateTo('wiki')} 
                className={`py-3 px-4 rounded text-left font-bold ${activeTab === 'wiki' ? 'bg-yellow-500/10 text-yellow-500' : 'text-zinc-400'}`}
              >
                WIKI & GUIDES
              </button>
            </div>
            
            <div className="h-[1px] bg-white/5 my-2" />

            <div className="flex items-center justify-between p-3 bg-zinc-950/60 rounded-xl border border-white/5">
              <span className="text-xs text-zinc-400 font-mono">Total Net Players:</span>
              <span className="text-emerald-400 font-mono font-black">{totalPlayersOnline} Online</span>
            </div>

            <button 
              onClick={() => { navigateTo('discord'); }}
              className="w-full bg-yellow-500 text-slate-950 py-3 uppercase tracking-wider font-bold rounded-xl text-center text-xs"
            >
              JOIN FLEX-MC DISCORD
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* HERO HERO SECTION (Global) */}
      <HeroSection totalPlayers={totalPlayersOnline} onNavigate={navigateTo} />

      {/* RENDER ACTIVE SCREEN */}
      <div className="flex-grow z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        
        {/* TAB 1: DASHBOARD / HUB ENTRY */}
        {activeTab === 'dashboard' && (
          <div className="space-y-12">
            
            {/* Server modes Selection segment */}
            <div>
              <div className="text-center max-w-xl mx-auto mb-8">
                <span className="text-[10px] uppercase text-yellow-500 tracking-[0.3em] font-pixel block mb-2">Three Sub-Servers, One Network</span>
                <h2 className="text-3xl font-extrabold uppercase tracking-tight text-white">Select Your Server Realm</h2>
                <p className="text-zinc-400 text-sm mt-2">Check game server statuses, features, strict custom rank perks or guidelines and jump straight into action.</p>
              </div>

              {/* Three mode buttons toggles */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* 1. ANARCHY CARD SELECTOR */}
                <button 
                  onClick={() => setSelectedServer('anarchy')}
                  className={`relative flex flex-col p-6 rounded-2xl cursor-pointer text-left transition-all duration-300 border ${selectedServer === 'anarchy' ? 'bg-zinc-900/90 border-yellow-500 shadow-2xl shadow-yellow-500/5' : 'bg-zinc-900/30 border-white/5 hover:bg-zinc-900/50'}`}
                >
                  <div className="flex justify-between items-center w-full mb-3">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-rose-500/10 rounded-lg text-rose-500">
                        <Skull className="w-5 h-5 animate-pulse" />
                      </div>
                      <span className="font-extrabold text-white tracking-wide uppercase text-sm">ANARCHY UNBOUND</span>
                    </div>
                    {/* Live indicator tag */}
                    <div className="flex items-center gap-1.5 font-mono text-xs text-yellow-500 font-bold bg-yellow-500/5 px-2 py-0.5 rounded-md border border-yellow-500/10">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <span>{SERVERS_INFO.anarchy.playersCount} Players</span>
                    </div>
                  </div>
                  <p className="text-xs text-zinc-400 line-clamp-2 mb-4">No administrators, no block claims. Hacks fully enabled survival with active proximity chat.</p>
                  
                  <div className="mt-auto flex items-center justify-between text-[11px] font-semibold text-zinc-500">
                    <span>Ver: {SERVERS_INFO.anarchy.version}</span>
                    <span className="text-yellow-500 group-hover:underline flex items-center gap-1">Configure Realm <ChevronRight className="w-3.5 h-3.5" /></span>
                  </div>
                </button>

                {/* 2. SKYBLOCK CARD SELECTOR */}
                <button 
                  onClick={() => setSelectedServer('skyblock')}
                  className={`relative flex flex-col p-6 rounded-2xl cursor-pointer text-left transition-all duration-300 border ${selectedServer === 'skyblock' ? 'bg-zinc-900/90 border-yellow-500 shadow-2xl shadow-yellow-500/5' : 'bg-zinc-900/30 border-white/5 hover:bg-zinc-900/50'}`}
                >
                  <div className="flex justify-between items-center w-full mb-3">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-cyan-500/10 rounded-lg text-cyan-400">
                        <Compass className="w-5 h-5" />
                      </div>
                      <span className="font-extrabold text-white tracking-wide uppercase text-sm">SKYBLOCK REALMS</span>
                    </div>
                    {/* Live indicator tag */}
                    <div className="flex items-center gap-1.5 font-mono text-xs text-yellow-500 font-bold bg-yellow-500/5 px-2 py-0.5 rounded-md border border-yellow-500/10">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <span>{SERVERS_INFO.skyblock.playersCount} Players</span>
                    </div>
                  </div>
                  <p className="text-xs text-zinc-400 line-clamp-2 mb-4">Island progression, robotic minion automatic farming, dynamic trade market & seasons.</p>
                  
                  <div className="mt-auto flex items-center justify-between text-[11px] font-semibold text-zinc-500">
                    <span>Ver: {SERVERS_INFO.skyblock.version}</span>
                    <span className="text-yellow-500 flex items-center gap-1">Configure Realm <ChevronRight className="w-3.5 h-3.5" /></span>
                  </div>
                </button>

                {/* 3. PVP ARENA CARD SELECTOR */}
                <button 
                  onClick={() => setSelectedServer('pvp')}
                  className={`relative flex flex-col p-6 rounded-2xl cursor-pointer text-left transition-all duration-300 border ${selectedServer === 'pvp' ? 'bg-zinc-900/90 border-yellow-500 shadow-2xl shadow-yellow-500/5' : 'bg-zinc-900/30 border-white/5 hover:bg-zinc-900/50'}`}
                >
                  <div className="flex justify-between items-center w-full mb-3">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-red-500/10 rounded-lg text-red-500">
                        <Swords className="w-5 h-5" />
                      </div>
                      <span className="font-extrabold text-white tracking-wide uppercase text-sm">PVP ARENAS & DUELS</span>
                    </div>
                    {/* Live indicator tag */}
                    <div className="flex items-center gap-1.5 font-mono text-xs text-yellow-500 font-bold bg-yellow-500/5 px-2 py-0.5 rounded-md border border-yellow-500/10">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <span>{SERVERS_INFO.pvp.playersCount} Players</span>
                    </div>
                  </div>
                  <p className="text-xs text-zinc-400 line-clamp-2 mb-4">Click-optimized 1.8剣 sword hitreg, practice duels, ELO rankings & competitive cash tourneys.</p>
                  
                  <div className="mt-auto flex items-center justify-between text-[11px] font-semibold text-zinc-500">
                    <span>Ver: {SERVERS_INFO.pvp.version}</span>
                    <span className="text-yellow-500 flex items-center gap-1">Configure Realm <ChevronRight className="w-3.5 h-3.5" /></span>
                  </div>
                </button>
              </div>
            </div>

            {/* DYNAMIC SELECTED MODE AREA PANEL */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start duration-500">
              
              {/* SERVER MODE OVERVIEW & FEATURES (Col span 8) */}
              <div className="lg:col-span-8 space-y-8">
                
                {/* Featured Mode Big Banner */}
                <div className="relative overflow-hidden rounded-2xl border border-white/5 bg-gradient-to-r from-zinc-900 to-zinc-950 p-6 md:p-8">
                  {/* Glowing dynamic gradient corner backdrop */}
                  <div className={`absolute top-0 right-0 w-64 h-64 rounded-full blur-[100px] opacity-10 pointer-events-none ${
                    selectedServer === 'anarchy' ? 'bg-red-500' : selectedServer === 'skyblock' ? 'bg-cyan-500' : 'bg-emerald-500'
                  }`} />

                  <div className="absolute top-4 right-4 text-zinc-500">
                    <div className="flex items-center gap-4 text-[11px] font-mono">
                      <span>PING: <strong className="text-emerald-400">{SERVERS_INFO[selectedServer].ping}ms</strong></span>
                      <span>UPTIME: <strong className="text-slate-200">{SERVERS_INFO[selectedServer].uptime}</strong></span>
                    </div>
                  </div>

                  <div className="inline-block px-2.5 py-1 bg-yellow-500 text-slate-950 text-[10px] font-pixel rounded-md mb-4 uppercase tracking-wider">
                    Realm Status Overview
                  </div>

                  <h3 className="text-3xl md:text-4xl font-black text-white uppercase tracking-tight">
                    {SERVERS_INFO[selectedServer].name}
                  </h3>
                  
                  <p className="text-zinc-400 text-sm max-w-2xl mt-3 leading-relaxed">
                    {SERVERS_INFO[selectedServer].description}
                  </p>

                  <div className="mt-6 flex flex-wrap gap-4 text-xs font-semibold text-zinc-400">
                    <div className="bg-zinc-950/40 border border-white/5 rounded-lg px-3 py-1.5 flex items-center gap-2">
                      <Server className="w-3.5 h-3.5 text-yellow-500" />
                      <span>Core: {SERVERS_INFO[selectedServer].hardware}</span>
                    </div>
                    {SERVERS_INFO[selectedServer].voicePluginRequired && (
                      <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg px-3 py-1.5 text-yellow-500 flex items-center gap-1.5">
                        <Mic className="w-3.5 h-3.5" />
                        <span>Requires Proximity Voice Mod</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Features list */}
                <div>
                  <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em] mb-4">Unique Game System Features</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {FEATURES_DATA[selectedServer].map((feature, idx) => {
                      // Lookup a proper icon for design pairing
                      let IconComponent = Sparkles;
                      if (feature.iconName === 'Compass') IconComponent = Compass;
                      else if (feature.iconName === 'ShieldAlert') IconComponent = ShieldAlert;
                      else if (feature.iconName === 'Mic') IconComponent = Mic;
                      else if (feature.iconName === 'Cpu') IconComponent = Cpu;
                      else if (feature.iconName === 'UserRound') IconComponent = UserRound;
                      else if (feature.iconName === 'TrendingUp') IconComponent = TrendingUp;
                      else if (feature.iconName === 'LayoutGrid') IconComponent = LayoutGrid;
                      else if (feature.iconName === 'Coins') IconComponent = Coins;
                      else if (feature.iconName === 'Swords') IconComponent = Swords;
                      else if (feature.iconName === 'Trophy') IconComponent = Trophy;
                      else if (feature.iconName === 'Volume2') IconComponent = Volume2;
                      else if (feature.iconName === 'Zap') IconComponent = Zap;

                      return (
                        <div key={idx} className="flex gap-4 p-5 bg-zinc-900/20 border border-white/5 rounded-2xl hover:border-zinc-800 transition-all group">
                          <div className="p-3 bg-zinc-950 rounded-xl text-yellow-500 border border-white/5 group-hover:scale-105 transition-transform self-start">
                            <IconComponent className="w-5 h-5" />
                          </div>
                          <div>
                            <h5 className="font-bold text-white text-sm tracking-wide mb-1 flex items-center gap-1.5">
                              {feature.title}
                            </h5>
                            <p className="text-xs text-zinc-400 leading-relaxed">{feature.description}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Active Rules & Moderation */}
                <div>
                  <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em] mb-4">Mode Execution Rules</h4>
                  <div className="space-y-3">
                    {RULES_DATA[selectedServer].map((rule) => (
                      <div key={rule.id} className="flex gap-4 p-4 bg-zinc-950/40 border border-white/5 rounded-xl text-left items-start">
                        <div className={`px-2 py-1 rounded text-[9px] font-pixel font-black ${
                          rule.severity === 'high' ? 'bg-red-500/10 text-red-500 border border-red-500/20' :
                          rule.severity === 'medium' ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20' :
                          'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        }`}>
                          {rule.severity.toUpperCase()}
                        </div>
                        <div>
                          <h5 className="font-bold text-white text-sm">{rule.title}</h5>
                          <p className="text-xs text-zinc-400 mt-0.5 leading-relaxed">{rule.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Rank perks and Quick Store Link */}
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em]">Available Shop Ranks</h4>
                    <button onClick={() => navigateTo('store')} className="text-xs font-bold text-yellow-500 hover:text-yellow-400 flex items-center gap-1 cursor-pointer">
                      Open Server Store →
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {RANK_PERKS[selectedServer].map((rank, i) => (
                      <div key={i} className="bg-gradient-to-b from-zinc-900 to-zinc-950 border border-white/5 rounded-2xl p-6 relative overflow-hidden group hover:border-zinc-800 transition-all flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <span className="text-[10px] uppercase font-mono text-zinc-500">Tier {i + 1} Perk Package</span>
                              <h5 className="text-2xl font-black tracking-tight text-white mt-0.5 flex items-center gap-2">
                                <span className={`bg-gradient-to-r ${rank.color} bg-clip-text text-transparent`}>{rank.name}</span>
                              </h5>
                            </div>
                            <div className="text-right">
                              <span className="text-xs font-mono font-bold text-yellow-500 bg-yellow-500/5 px-2 py-1 rounded border border-yellow-500/10">{rank.price}</span>
                            </div>
                          </div>

                          <div className="mb-4 inline-flex items-center gap-2 px-2.5 py-1 bg-zinc-950 rounded-lg text-[10px] font-mono border border-white/5 text-zinc-400">
                            <Activity className="w-3 h-3 text-emerald-500" />
                            <span>Speed Gain: <strong>{rank.multiplier}</strong></span>
                          </div>

                          <ul className="space-y-2 text-xs text-zinc-400 mb-6">
                            {rank.perks.map((per, idx) => (
                              <li key={idx} className="flex gap-2">
                                <Check className="w-3.5 h-3.5 text-yellow-500 shrink-0 mt-0.5" />
                                <span>{per}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <button 
                          onClick={() => {
                            // Find corresponding item or use matching filter
                            const matchItem = STORE_ITEMS.find(item => item.name.toLowerCase().includes(rank.name.toLowerCase()));
                            if (matchItem) {
                              addToCart(matchItem);
                            } else {
                              navigateTo('store');
                            }
                          }}
                          className={`w-full py-3 bg-zinc-900 hover:bg-zinc-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl border border-white/5 hover:border-yellow-500/30 transition-all flex items-center justify-center gap-2 cursor-pointer`}
                        >
                          <ShoppingCart className="w-3.5 h-3.5" />
                          <span>Buy {rank.name} rank</span>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* ACTIVE PROXIMITY VOICE CHAT SOUND INTERACTIVE RADAR (For Anarchy & PvP modes) */}
                {SERVERS_INFO[selectedServer].voicePluginRequired && (
                  <div className="bg-gradient-to-br from-zinc-950 to-zinc-900 border border-white/10 rounded-2xl p-6 md:p-8 space-y-6">
                    
                    <div className="flex flex-col sm:flex-row gap-4 items-start justify-between">
                      <div className="flex gap-3 items-center">
                        <div className="p-3 bg-yellow-500/10 rounded-xl text-yellow-500 border border-yellow-500/20">
                          <Mic className="w-6 h-6 animate-pulse" />
                        </div>
                        <div>
                          <span className="text-[10px] uppercase font-pixel tracking-wider text-yellow-500 block">Proximity Plug-In Center</span>
                          <h4 className="font-extrabold text-white text-lg mt-0.5">Live Sound Radar Simulator</h4>
                        </div>
                      </div>
                      
                      <button 
                        onClick={() => setIsAudioTesting(!isAudioTesting)}
                        className={`px-4 py-2 text-xs font-bold uppercase rounded-xl transition-all cursor-pointer ${
                          isAudioTesting 
                            ? 'bg-rose-500/15 border border-rose-500/30 text-rose-400' 
                            : 'bg-yellow-500 text-slate-950'
                        }`}
                      >
                        {isAudioTesting ? 'Stop Simulation' : 'Test Audio Experience'}
                      </button>
                    </div>

                    <p className="text-xs text-zinc-400 leading-relaxed">
                      Move the slider below to drag your virtual player proximity coordinates away from standard sound server feeds and preview real-time audio volume dynamics.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                      
                      {/* Control Panel (Col span 5) */}
                      <div className="md:col-span-5 space-y-4">
                        <div className="bg-zinc-950/60 p-4 rounded-xl border border-white/5">
                          <div className="flex justify-between text-xs font-mono text-zinc-500 mb-1">
                            <span>SURVIVOR RANGE:</span>
                            <span className="text-white font-bold">{soundRadarDistance} Blocks</span>
                          </div>
                          
                          <input 
                            type="range" 
                            min="0" 
                            max="100" 
                            value={soundRadarDistance}
                            onChange={(e) => {
                              setSoundRadarDistance(Number(e.target.value));
                              if (!isAudioTesting) setIsAudioTesting(true);
                            }}
                            className="w-full accent-yellow-500 h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                          />
                          
                          <div className="flex justify-between text-[10px] text-zinc-500 mt-2 font-mono">
                            <span>0m (Crisp Audio)</span>
                            <span>100m (Out of Sync)</span>
                          </div>
                        </div>

                        <div className="bg-zinc-950/60 p-4 rounded-xl border border-white/5 flex items-center justify-between text-xs">
                          <span className="font-mono text-zinc-400">Audio Volume output:</span>
                          <span className="font-mono text-emerald-400 font-bold">{isAudioTesting ? `${Math.round(voiceVolumeScale)}%` : '0% (Muted)'}</span>
                        </div>
                      </div>

                      {/* Display Radar pulse (Col span 7) */}
                      <div className="md:col-span-7 flex justify-center">
                        <div className="w-56 h-56 bg-zinc-950 rounded-full border border-white/5 relative flex items-center justify-center overflow-hidden">
                          {/* Pulsing circles on active testing */}
                          {isAudioTesting && (
                            <>
                              <div 
                                className="absolute border border-yellow-500/20 rounded-full animate-ping pointer-events-none" 
                                style={{ 
                                  width: `${100 - soundRadarDistance}%`, 
                                  height: `${100 - soundRadarDistance}%`,
                                  animationDuration: '3s'
                                }} 
                              />
                              <div className="absolute w-[80%] h-[80%] border border-white/5 rounded-full" />
                              <div className="absolute w-[50%] h-[50%] border border-white/5 rounded-full" />
                            </>
                          )}

                          {/* Radar Scan lines */}
                          <div className="absolute inset-0 bg-[radial-gradient(circle,_transparent_30%,_rgba(0,0,0,0.8)_85%)]" />

                          {/* Radar Target Center (Your mic helper) */}
                          <div className="z-10 bg-slate-900 border border-yellow-500/50 p-2.5 rounded-full text-yellow-500 shadow-xl">
                            <Mic className="w-5 h-5" />
                          </div>

                          {/* Draggable user coordinates dots position Indicator */}
                          <div 
                            className="absolute z-10 duration-200 transition-all"
                            style={{
                              transform: `translate(${Math.cos(Date.now() / 1500) * (soundRadarDistance * 1.0)}px, ${Math.sin(Date.now() / 1500) * (soundRadarDistance * 1.0)}px)`
                            }}
                          >
                            <div className="relative">
                              <div className="absolute -inset-1.5 bg-cyan-400 rounded-full animate-pulse blur-[4px]" />
                              <div className="w-3.5 h-3.5 bg-cyan-500 rounded-full border-1 border-white shadow-md shadow-cyan-500/50" />
                              <span className="absolute left-5 -top-1 px-1.5 py-0.5 whitespace-nowrap bg-zinc-900 border border-white/10 text-[9px] font-mono rounded text-zinc-300">Survivor</span>
                            </div>
                          </div>

                          {/* Radar grid coordinates text */}
                          <p className="absolute bottom-2.5 text-[8px] font-mono text-zinc-600 uppercase tracking-widest pointer-events-none">Proximity Radar Grid</p>
                        </div>
                      </div>

                    </div>

                    <div className="text-center">
                      <button 
                        onClick={() => navigateTo('wiki')}
                        className="text-xs font-bold text-yellow-500 hover:text-yellow-400 hover:underline inline-flex items-center gap-1 cursor-pointer"
                      >
                        Read Proximity Client Setup Guide <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>

                  </div>
                )}

              </div>

              {/* SIDEBAR LADDERS, CHAT TERMINAL & NEWS TABS (Col span 4) */}
              <div className="lg:col-span-4 space-y-8">
                
                {/* 1. SECTOR LEADERBOARD (Dynamic to server selected) */}
                <div className="bg-zinc-900/40 border border-white/5 rounded-2xl p-5 flex flex-col">
                  
                  <div className="flex justify-between items-center mb-4">
                    <div className="flex items-center gap-2">
                      <Trophy className="w-4 h-4 text-yellow-500" />
                      <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest">
                        {selectedServer.toUpperCase()} Ranked Ladder
                      </h3>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Top 5</span>
                  </div>

                  <div className="space-y-2">
                    {LEADERBOARD_DATA[selectedServer].map((entry, index) => (
                      <div 
                        key={index}
                        className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                          index === 0 
                            ? 'bg-yellow-500/5 border-yellow-500/20 shadow-lg' 
                            : 'bg-zinc-950/40 border-white/5 hover:border-zinc-800'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className={`text-xs font-pixel font-bold w-5 text-center ${
                            index === 0 ? 'text-yellow-500' : index === 1 ? 'text-zinc-400' : index === 2 ? 'text-amber-700' : 'text-zinc-600'
                          }`}>
                            0{entry.position}
                          </span>

                          <div className="flex flex-col text-left">
                            <span className="text-xs font-extrabold text-white flex items-center gap-1.5 leading-none">
                              {entry.username}
                              {entry.tag && (
                                <span className="text-[8px] px-1 py-0.5 rounded bg-zinc-800 text-zinc-300 font-sans tracking-wide">
                                  {entry.tag}
                                </span>
                              )}
                            </span>
                            <span className="text-[10px] text-zinc-500 mt-1 font-mono">{entry.extraStatLabel}: <strong className="text-zinc-400">{entry.extraStatValue}</strong></span>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-xs font-mono font-semibold text-yellow-500">{entry.statValue}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2. INTERACTIVE MINECRAFT CHAT TERMINAL OVERLAY */}
                <div className="bg-zinc-900/40 border border-white/5 rounded-2xl p-5 flex flex-col">
                  
                  <div className="flex justify-between items-center mb-3">
                    <div className="flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-yellow-500" />
                      <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Live Server Global Chat</h3>
                    </div>
                    <span className="flex h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  </div>
                  
                  <p className="text-[10px] text-zinc-500 text-left mb-3">Interactive bridge. Change nickname, type a custom chat line and witness your text populate in real-time!</p>

                  {/* Terminal viewport log */}
                  <div className="bg-zinc-950/90 rounded-xl p-3 border border-white/5 font-mono text-[10px] h-60 overflow-y-auto space-y-2 flex flex-col justify-end">
                    
                    {chatFeed.map((chat) => (
                      <div key={chat.id} className="text-left leading-relaxed">
                        <span className="text-zinc-600 mr-1">[{chat.timestamp}]</span>
                        <span className="text-yellow-500/80 mr-1 uppercase text-[8px] bg-yellow-500/5 px-1 py-0.2 rounded border border-yellow-500/10">{chat.server.toUpperCase()}</span>
                        {chat.prefix && (
                          <span className={`${chat.prefixColor || 'text-zinc-400'} font-bold mr-1`}>{chat.prefix}</span>
                        )}
                        <span className="text-zinc-300 font-bold mr-1">{chat.username}:</span>
                        <span className="text-zinc-400 break-all">{chat.message}</span>
                      </div>
                    ))}
                    
                    {chatFeed.length === 0 && (
                      <div className="text-zinc-600 italic py-4 text-center">No active chatter. Type something below...</div>
                    )}
                  </div>

                  {/* Submit mini chat controller */}
                  <form onSubmit={handleSendMessage} className="mt-3 space-y-2.5">
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[9px] text-zinc-500 uppercase font-bold tracking-wider block mb-1">Nickname</label>
                        <input 
                          type="text" 
                          placeholder="YourName"
                          value={userNickname}
                          onChange={(e) => setUserNickname(e.target.value.substring(0, 14))}
                          className="w-full bg-zinc-950/80 border border-white/5 text-[10px] px-2 py-1.5 text-white rounded font-mono focus:outline-none focus:border-yellow-500/30"
                        />
                      </div>
                      <div>
                        <label className="text-[9px] text-zinc-500 uppercase font-bold tracking-wider block mb-1">Server Lobby</label>
                        <select 
                          value={selectedChatServer} 
                          onChange={(e) => setSelectedChatServer(e.target.value as any)}
                          className="w-full bg-zinc-950/80 border border-white/5 text-[10px] px-1 py-1.5 text-zinc-300 rounded font-mono focus:outline-none cursor-pointer"
                        >
                          <option value="hub">Hub</option>
                          <option value="anarchy">Anarchy</option>
                          <option value="skyblock">SkyBlock</option>
                          <option value="pvp">PvP Arena</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        placeholder="Type message..."
                        value={userChatMessage}
                        onChange={(e) => setUserChatMessage(e.target.value.substring(0, 80))}
                        className="flex-grow bg-zinc-950 px-3 py-2 border border-white/5 text-xs text-zinc-100 rounded-xl focus:outline-none focus:border-yellow-500/50"
                      />
                      <button 
                        type="submit" 
                        className="bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-black px-4 py-2 rounded-xl text-[10px] uppercase tracking-wider shrink-0 cursor-pointer transition-colors"
                      >
                        Send
                      </button>
                    </div>

                  </form>
                </div>

                {/* 3. INTERACTIVE MINI DISCORD INTEGRATION CARD */}
                <div className="bg-gradient-to-b from-[#18191c] to-[#0f1012] border border-[#2c2f33]/40 rounded-2xl p-5 flex flex-col shadow-2xl relative overflow-hidden text-left">
                  {/* Glowing discord blur background */}
                  <div className="absolute top-0 right-0 w-32 h-32 bg-[#5865F2]/10 rounded-full blur-2xl pointer-events-none" />
                  
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 bg-[#5865F2] rounded-xl flex items-center justify-center text-white">
                        <MessageCircle className="w-5 h-5 fill-white" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-white text-sm">Flex-MC Discord</h4>
                        <span className="text-[10px] text-[#5865F2]/90 font-mono font-bold">WIDGET ONLINE</span>
                      </div>
                    </div>

                    <div className="px-2 py-0.5 rounded-full bg-[#5865F2]/10 border border-[#5865F2]/20 text-[9px] font-mono text-[#5865F2] font-semibold">
                      ● 1,492 ONLINE
                    </div>
                  </div>

                  <p className="text-xs text-zinc-400 leading-relaxed mb-4">
                    Connect with over <strong>8,200 gamers</strong>. Exchange resources coordinate base raids or claim event prizes!
                  </p>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center justify-between p-2.5 bg-zinc-950/50 rounded-lg border border-white/5 text-[11px]">
                      <span className="text-zinc-500 font-mono">🔊 General Voice Lobbies</span>
                      <span className="text-zinc-400 font-bold font-mono">24 channels</span>
                    </div>
                    <div className="flex items-center justify-between p-2.5 bg-zinc-950/50 rounded-lg border border-white/2 my-2 text-[11px]">
                      <span className="text-zinc-500 font-mono">⚡ Multi-Server Sync Status</span>
                      <span className="text-emerald-500 font-bold uppercase tracking-wider text-[10px]">Connected</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => navigateTo('discord')}
                    className="w-full bg-[#5865F2] hover:bg-[#4752c4] text-white font-bold py-2.5 rounded-xl uppercase tracking-wider text-xs transition-colors flex items-center justify-center gap-2"
                  >
                    <span>Launch Discord Centre</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>

              </div>

            </div>

            {/* NEWS SECTION (Dedicated grid display inside main dashboard) */}
            <div className="border-t border-white/5 pt-12">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
                <div>
                  <span className="text-[10px] uppercase text-yellow-500 tracking-[0.25em] font-pixel block mb-1">Flex-MC Server Publications</span>
                  <h3 className="text-2xl font-black uppercase text-white tracking-tight">Community News & Up-to-Date Alerts</h3>
                </div>
                
                <div className="inline-flex items-center gap-2 text-xs font-semibold text-zinc-500">
                  <span>Showing latest 3 postings sorted by date</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {NEWS_ARTICLES.map((article) => (
                  <div key={article.id} className="bg-zinc-900/40 border border-white/5 rounded-2xl p-5 flex flex-col justify-between hover:border-zinc-800 transition-all group">
                    <div>
                      <div className="overflow-hidden rounded-xl h-44 mb-4 relative bg-zinc-950 border border-white/5">
                        <img 
                          src={article.image} 
                          alt={article.title} 
                          className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute top-3 left-3 px-2 py-0.5 rounded bg-zinc-900/90 text-[9px] font-bold text-yellow-500 tracking-wider uppercase">
                          {article.category}
                        </div>
                        <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded bg-zinc-950/90 text-[9px] font-mono text-zinc-400">
                          {article.readTime}
                        </div>
                      </div>

                      <span className="text-[10px] font-mono font-semibold text-zinc-500">{article.date} — By {article.author}</span>
                      <h4 className="font-extrabold text-white text-base mt-1.5 group-hover:text-yellow-400 duration-200">{article.title}</h4>
                      <p className="text-xs text-zinc-400 mt-2 line-clamp-3 leading-relaxed">{article.excerpt}</p>
                    </div>

                    <button 
                      onClick={() => setSelectedNews(article)}
                      className="mt-5 w-full py-2.5 bg-zinc-900/60 hover:bg-zinc-900 text-zinc-300 font-bold text-xs rounded-xl border border-white/5 hover:border-zinc-700 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <span>Read Publication</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: STORE SCREEN */}
        {activeTab === 'store' && (
          <div className="space-y-8">
            
            {/* Store title & instructions */}
            <div className="text-center max-w-xl mx-auto">
              <span className="text-[10px] uppercase text-yellow-500 tracking-[0.3em] font-pixel block mb-2">Support Flex-MC server</span>
              <h2 className="text-4xl font-extrabold uppercase tracking-tight text-white mb-2">Web Server Shop & Perks</h2>
              <p className="text-zinc-400 text-sm">Choose server ranks, automated crate packages, cosmetic wings, and boosters to maximize support for server hosting costs!</p>
            </div>

            {/* Cart helper reminder button */}
            {cart.length > 0 && (
              <div className="bg-gradient-to-r from-yellow-500/10 to-amber-500/15 border border-yellow-500/20 p-4 rounded-xl flex items-center justify-between shadow-2xl">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-yellow-500 text-slate-950 font-bold rounded-lg relative">
                    <ShoppingCart className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="font-bold text-white text-sm">Active Shopping Cart ({cart.reduce((s, c) => s + c.quantity, 0)} Items)</h5>
                    <p className="text-xs text-zinc-400">Total basket value equals <strong>€{cartTotal.toFixed(2)}</strong>. Complete checkout instantly!</p>
                  </div>
                </div>

                <button 
                  onClick={() => setIsCartOpen(true)}
                  className="bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-bold px-4 py-2 text-xs rounded-xl uppercase tracking-wider cursor-pointer"
                >
                  Checkout Basket
                </button>
              </div>
            )}

            {/* Shop Category Tabs selectors */}
            <div className="flex flex-wrap gap-2 justify-center border-b border-white/5 pb-6">
              {[
                { id: 'all', label: 'All Store Packs' },
                { id: 'ranks', label: 'Server Perks' },
                { id: 'keys', label: 'Treasure Keys' },
                { id: 'boosters', label: 'Global Boosters' },
                { id: 'cosmetics', label: 'Cosmetics & Wings' },
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setStoreCategory(cat.id as any)}
                  className={`px-4.5 py-2.5 rounded-xl font-bold uppercase tracking-wider text-xs transition-colors cursor-pointer border ${
                    storeCategory === cat.id 
                      ? 'bg-yellow-500 text-slate-950 border-yellow-500 hover:bg-yellow-400' 
                      : 'bg-zinc-900/50 hover:bg-zinc-900 hover:text-white text-zinc-400 border-white/5'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Shop items display list */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {filteredStoreItems.map((item) => (
                <div key={item.id} className="bg-zinc-900/40 border border-white/5 rounded-2xl p-6 flex flex-col justify-between hover:border-zinc-800 transition-all group">
                  
                  <div>
                    <div className="flex justify-between items-start mb-4">
                      <span className="text-[10px] uppercase font-mono tracking-wider text-zinc-500">{item.category} pack</span>
                      {item.badge && (
                        <span className={`px-2 py-0.5 rounded text-[9px] font-pixel text-slate-950 ${
                          item.badge.includes('Off') || item.badge.includes('Sale') ? 'bg-red-500 text-white font-sans font-bold' : 'bg-yellow-500'
                        }`}>
                          {item.badge}
                        </span>
                      )}
                    </div>

                    <h3 className="font-extrabold text-white text-lg tracking-wide group-hover:text-yellow-400 transition-colors leading-snug">
                      {item.name}
                    </h3>
                    
                    <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
                      {item.description}
                    </p>

                    <div className="my-4 h-[1px] bg-white/5" />

                    <ul className="space-y-2 mb-6 text-xs text-zinc-400">
                      {item.features.map((f, i) => (
                        <li key={i} className="flex gap-2.5">
                          <Check className="w-3.5 h-3.5 text-yellow-500 shrink-0 mt-0.5" />
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <div className="flex items-baseline gap-2 mb-4">
                      <span className="text-2xl font-black font-mono text-white">€{item.price}</span>
                      {item.originalPrice && (
                        <span className="text-xs font-mono text-zinc-500 line-through">€{item.originalPrice}</span>
                      )}
                    </div>

                    <button
                      onClick={() => addToCart(item)}
                      className="w-full py-3.5 bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-bold uppercase tracking-wider rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/5 group-hover:shadow-yellow-500/10"
                    >
                      <ShoppingCart className="w-4 h-4" />
                      <span>Add to Shopping Cart</span>
                    </button>
                  </div>

                </div>
              ))}

              {filteredStoreItems.length === 0 && (
                <div className="col-span-full py-16 text-center text-zinc-500">No store items fit the select filter category.</div>
              )}
            </div>

            {/* Quick checkout process breakdown */}
            <div className="bg-zinc-950 p-6 rounded-2xl border border-white/5 space-y-4">
              <h4 className="font-extrabold text-white text-sm uppercase tracking-wider mb-2">Secure Store Processing and Claims info</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
                <div className="flex gap-3">
                  <div className="p-2.5 bg-zinc-900 border border-white/5 text-yellow-500 rounded-xl h-10 w-10 flex items-center justify-center font-bold font-mono">1</div>
                  <div>
                    <p className="font-bold text-zinc-300">Input Game ID in Checkout</p>
                    <p className="text-zinc-500 mt-1">Specify your exact Minecraft case-sensitive screen name during complete payment.</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="p-2.5 bg-zinc-900 border border-white/5 text-yellow-500 rounded-xl h-10 w-10 flex items-center justify-center font-bold font-mono">2</div>
                  <div>
                    <p className="font-bold text-zinc-300">Instant Delivery Routine</p>
                    <p className="text-zinc-500 mt-1">Our automated database processing system dispatches ranks within standard 3-5 minutes inside Minecraft.</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="p-2.5 bg-zinc-900 border border-white/5 text-yellow-500 rounded-xl h-10 w-10 flex items-center justify-center font-bold font-mono">3</div>
                  <div>
                    <p className="font-bold text-zinc-300">Run `/claim` or Join Lobby</p>
                    <p className="text-zinc-500 mt-1">Simply log in to the server hub IP: {SERVER_IP} and type command `/claim` in server text chat box.</p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* TAB 3: DISCORD COMMUNITY CENTRE */}
        {activeTab === 'discord' && (
          <div className="space-y-8">
            
            {/* Header branding */}
            <div className="text-center max-w-xl mx-auto">
              <span className="text-[10px] uppercase text-[#5865F2] tracking-[0.3em] font-pixel block mb-2">Minecraft Discord Connection</span>
              <h2 className="text-4xl font-extrabold uppercase tracking-tight text-white mb-2">Community Center HUB</h2>
              <p className="text-zinc-400 text-sm">Join tactical voice mod lobbies, chat in real-time with server staff, trade resources and view server announcements.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Live Discord Widget Mock Simulator (Col span 8) */}
              <div className="lg:col-span-8 space-y-6">
                
                {/* Embedded Discord style layout */}
                <div className="bg-[#2f3136] rounded-2xl overflow-hidden border border-white/5 shadow-2xl flex flex-col">
                  
                  {/* Discord channel banner line */}
                  <div className="bg-[#202225] p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-white">
                        <MessageCircle className="w-4.5 h-4.5" />
                      </div>
                      <div className="flex flex-col text-left">
                        <h4 className="font-extrabold text-white text-xs tracking-wide">FLEX-MC DISCORD BRIDGE</h4>
                        <span className="text-[9px] text-zinc-500 font-semibold font-mono">SERVER WIDGET INTEGRATION</span>
                      </div>
                    </div>

                    <a
                      href="https://discord.gg/SQPPFVtdxx"
                      target="_blank"
                      rel="noreferrer"
                      className="px-3.5 py-1.5 bg-[#5865F2] hover:bg-[#4752c4] text-white font-bold text-[10px] rounded-lg uppercase tracking-wider flex items-center gap-1"
                    >
                      <span>Join Discord invite Link</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  {/* Inside layout */}
                  <div className="grid grid-cols-1 md:grid-cols-12 h-112">
                    
                    {/* Channel lists/Sidebar (col span 4) */}
                    <div className="md:col-span-4 bg-[#2f3136] border-r border-[#202225] p-3 flex flex-col justify-between">
                      <div className="space-y-4">
                        <div>
                          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest pl-2">TEXT CHANNELS</span>
                          <div className="mt-2 space-y-1">
                            <div className="px-2.5 py-1.5 bg-[#34363c] text-white rounded text-xs font-semibold cursor-pointer">
                              # 📢 announcements
                            </div>
                            <div className="px-2.5 py-1.5 hover:bg-[#34363c]/50 text-zinc-400 rounded text-xs font-semibold cursor-pointer">
                              # 💬 off-topic-chat
                            </div>
                            <div className="px-2.5 py-1.5 hover:bg-[#34363c]/50 text-zinc-400 rounded text-xs font-semibold cursor-pointer">
                              # 🛠️ staff-application
                            </div>
                            <div className="px-2.5 py-1.5 hover:bg-[#34363c]/50 text-zinc-400 rounded text-xs font-semibold cursor-pointer">
                              # 💎 support-tickets
                            </div>
                          </div>
                        </div>

                        <div>
                          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest pl-2">VOICE CHANNELS</span>
                          <div className="mt-2 space-y-1">
                            <div className="px-2.5 py-1.5 hover:bg-[#34363c]/50 text-zinc-400 rounded text-xs font-semibold flex items-center justify-between cursor-pointer">
                              <span>🔊 Anarchy Squad Voice</span>
                              <span className="text-[9px] font-mono text-zinc-500 pr-1">4/10</span>
                            </div>
                            <div className="px-2.5 py-1.5 hover:bg-[#34363c]/50 text-zinc-400 rounded text-xs font-semibold flex items-center justify-between cursor-pointer">
                              <span>🔊 SkyBlock Island Co-Op</span>
                              <span className="text-[9px] font-mono text-emerald-400 pr-1">Active</span>
                            </div>
                            <div className="px-2.5 py-1.5 hover:bg-[#34363c]/50 text-zinc-400 rounded text-xs font-semibold flex items-center justify-between cursor-pointer">
                              <span>🔊 PvP Match Strategies</span>
                              <span className="text-[9px] font-mono text-zinc-500 pr-1">2/4</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="bg-[#202225] p-2.5 rounded-xl border border-white/5 flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-xs text-white">
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                          <span className="font-bold">Sync Enabled</span>
                        </div>
                        <span className="text-[8px] font-mono text-zinc-500 uppercase tracking-widest">v1.4.2</span>
                      </div>
                    </div>

                    {/* Chat channel contents panel (col span 8) */}
                    <div className="md:col-span-8 bg-[#36393f] p-4 flex flex-col justify-between">
                      
                      {/* Interactive mock discord feed messages list */}
                      <div className="space-y-4 overflow-y-auto h-85 text-left pr-2">
                        
                        <div className="flex gap-3">
                          <div className="w-8 h-8 rounded-full bg-yellow-500 flex items-center justify-center font-bold text-slate-950 text-xs shadow-xl shrink-0">A</div>
                          <div>
                            <div className="flex items-baseline gap-2">
                              <span className="font-extrabold text-yellow-500 text-xs">Admin_Flex-MC</span>
                              <span className="bg-yellow-500/10 border border-yellow-500/30 text-[8px] px-1 rounded font-mono text-yellow-500 uppercase font-black">ADMINISTRATOR</span>
                              <span className="text-[9px] text-zinc-500 font-mono">Today 4:12 PM</span>
                            </div>
                            <p className="text-zinc-300 text-xs mt-1 leading-relaxed">
                              Welcome survivors to standard Flex-MC community widget! Keep chats civilized and use support channels if ranks are taking more than 5 minutes to deliver on the hub.
                            </p>
                          </div>
                        </div>

                        <div className="flex gap-3">
                          <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center font-bold text-white text-xs shrink-0">W</div>
                          <div>
                            <div className="flex items-baseline gap-2">
                              <span className="font-extrabold text-[#5865F2] text-xs">Warlord_Spammer</span>
                              <span className="bg-rose-500/10 text-[8px] px-1 rounded font-mono text-rose-500 font-bold uppercase">WARLORD PERK</span>
                              <span className="text-[9px] text-zinc-500 font-mono">Today 5:02 PM</span>
                            </div>
                            <p className="text-zinc-300 text-xs mt-1 leading-relaxed">
                              The London hosting nodes got massive hardware upgrades. Average network latency on PvP Practice is literal 10ms for me right now!
                            </p>
                          </div>
                        </div>

                        <div className="flex gap-3">
                          <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center font-bold text-slate-950 text-xs shrink-0">C</div>
                          <div>
                            <div className="flex items-baseline gap-2">
                              <span className="font-extrabold text-emerald-400 text-xs">CpsMonster_1</span>
                              <span className="text-[9px] text-zinc-500 font-mono">Today 5:24 PM</span>
                            </div>
                            <p className="text-zinc-300 text-xs mt-1 leading-relaxed">
                              Is someone co-oping on SkyBlock Realms tonight? I have automated iron ore minion setups ready.
                            </p>
                          </div>
                        </div>

                        <div className="flex gap-3">
                          <div className="w-8 h-8 rounded-full bg-zinc-600 flex items-center justify-center font-bold text-white text-xs shrink-0">N</div>
                          <div>
                            <div className="flex items-baseline gap-2">
                              <span className="font-extrabold text-zinc-300 text-xs">NetworkBot</span>
                              <span className="bg-zinc-700 text-[8px] px-1 rounded font-mono text-zinc-400 uppercase">BOT</span>
                              <span className="text-[9px] text-zinc-500 font-mono">Just Now</span>
                            </div>
                            <p className="text-[#5865F2] text-xs mt-1 leading-relaxed italic font-semibold">
                              ★ USER PREVIEW: [You joined the Flex-MC Discord channel]
                            </p>
                          </div>
                        </div>

                      </div>

                      {/* Fake channel chat typing display */}
                      <div className="mt-3 flex gap-2">
                        <input 
                          type="text" 
                          disabled 
                          placeholder="You must join the Discord invite to chat..." 
                          className="flex-grow bg-[#2f313c] border border-zinc-800 disabled:opacity-60 px-3 py-2 text-xs text-zinc-500 rounded-xl"
                        />
                        <a 
                          href="https://discord.gg/SQPPFVtdxx" 
                          target="_blank" 
                          rel="noreferrer"
                          className="bg-[#5865F2] hover:bg-[#4752c4] text-white px-4 py-2 text-xs font-bold uppercase rounded-xl flex items-center shrink-0 cursor-pointer"
                        >
                          Join
                        </a>
                      </div>

                    </div>

                  </div>

                </div>

              </div>

              {/* Sidebar Community Stats and Information (Col span 4) */}
              <div className="lg:col-span-4 space-y-6 text-left">
                
                {/* Active Staff list */}
                <div className="bg-zinc-900/40 border border-white/5 rounded-2xl p-5">
                  <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-4">Online Server Operators</h4>
                  <div className="space-y-3">
                    
                    <div className="flex items-center justify-between p-2.5 bg-zinc-950/40 border border-white/5 rounded-xl">
                      <div className="flex items-center gap-2.5">
                        <div className="relative">
                          <div className="w-8 h-8 bg-purple-500/10 border-1 border-purple-500 text-purple-400 font-bold rounded-lg flex items-center justify-center text-xs">AF</div>
                          <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-zinc-950" />
                        </div>
                        <div className="flex flex-col text-left">
                          <span className="text-xs font-bold text-white">Admin_Flex</span>
                          <span className="text-[9px] text-zinc-500">Global Core Dev</span>
                        </div>
                      </div>
                      <span className="text-[8px] px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20 font-bold">ADMIN</span>
                    </div>

                    <div className="flex items-center justify-between p-2.5 bg-zinc-950/40 border border-white/5 rounded-xl">
                      <div className="flex items-center gap-2.5">
                        <div className="relative">
                          <div className="w-8 h-8 bg-red-500/10 border-1 border-red-500 text-red-500 font-bold rounded-lg flex items-center justify-center text-xs">MP</div>
                          <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-zinc-950" />
                        </div>
                        <div className="flex flex-col text-left">
                          <span className="text-xs font-bold text-white">Mod_Proximity</span>
                          <span className="text-[9px] text-zinc-500">Audio Moderator</span>
                        </div>
                      </div>
                      <span className="text-[8px] px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20 font-bold">MODERATOR</span>
                    </div>

                    <div className="flex items-center justify-between p-2.5 bg-zinc-950/40 border border-white/5 rounded-xl">
                      <div className="flex items-center gap-2.5">
                        <div className="relative">
                          <div className="w-8 h-8 bg-cyan-500/10 border-1 border-cyan-500 text-cyan-400 font-bold rounded-lg flex items-center justify-center text-xs">SK</div>
                          <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-amber-500 border border-zinc-950 animate-pulse" />
                        </div>
                        <div className="flex flex-col text-left">
                          <span className="text-xs font-bold text-white">SkyHelper_Pro</span>
                          <span className="text-[9px] text-zinc-500">Economy Moderator</span>
                        </div>
                      </div>
                      <span className="text-[8px] px-1.5 py-0.5 rounded bg-cyan-400/10 text-cyan-400 border border-cyan-500/20 font-bold">HELPER</span>
                    </div>

                  </div>
                </div>

                {/* Discord benefits list */}
                <div className="bg-gradient-to-br from-zinc-950 to-zinc-900 border border-white/5 rounded-2xl p-5 space-y-3 text-xs text-zinc-400">
                  <h4 className="font-extrabold text-white text-sm">Discord Join Perks</h4>
                  <p className="leading-relaxed">Entering the Minecraft network Discord secures unique rewards automatically:</p>
                  
                  <ul className="space-y-2 mt-2">
                    <li className="flex gap-2.5">
                      <Gift className="w-4 h-4 text-yellow-500 shrink-0" />
                      <span>Free Bronze Treasure Key upon connection UUID pairing</span>
                    </li>
                    <li className="flex gap-2.5">
                      <Trophy className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>Direct access to Saturday tournaments lobby registration keys</span>
                    </li>
                    <li className="flex gap-2.5">
                      <Mic className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>Dedicated proximity plugin setups chat rooms for Fabric/Forge help</span>
                    </li>
                  </ul>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* TAB 4: WIKI & GUIDES SCREEN */}
        {activeTab === 'wiki' && (
          <div className="space-y-12 text-left">
            
            {/* Title / Header content */}
            <div className="text-center max-w-xl mx-auto">
              <span className="text-[10px] uppercase text-yellow-500 tracking-[0.3em] font-pixel block mb-2">Setup guides & resources</span>
              <h2 className="text-4xl font-extrabold uppercase tracking-tight text-white mb-2">Wiki & Proximity Instructions</h2>
              <p className="text-zinc-400 text-sm">Everything you need to configure your Minecraft client mods, proximity voice systems, server commands, and explore gameplay mechanics.</p>
            </div>

            {/* Ultimate Proximity Mod Guide section */}
            <div className="bg-gradient-to-r from-zinc-900 via-zinc-950 to-zinc-950 border border-white/5 rounded-2xl p-6 md:p-10 space-y-6">
              
              <div className="flex flex-col md:flex-row gap-6 items-start md:items-center justify-between">
                <div className="flex gap-4 items-center">
                  <div className="p-3 bg-yellow-500/10 rounded-2xl text-yellow-500 border border-yellow-500/20 shrink-0">
                    <Mic className="w-8 h-8" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-pixel text-yellow-500 block">Required for Anarchy and PvP modes</span>
                    <h3 className="text-2xl font-black text-white mt-0.5">Simple Proximity Audio Configuration</h3>
                  </div>
                </div>

                <div className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-white/10 text-xs font-mono text-zinc-300">
                  Default Audio Bind Key: <strong>"V" Key</strong>
                </div>
              </div>

              <p className="text-xs text-zinc-400 leading-relaxed">
                Proximity sound uses client-to-server voice protocols. Experience immersive gaming by listening, talking with team factions, or organizing raids. Learn how to configure it in 4 quick steps:
              </p>

              {/* Steps breakdown list grid */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {VOICE_CHAT_GUIDE.map((step) => (
                  <div key={step.step} className="bg-zinc-950 border border-white/5 p-5 rounded-xl space-y-2.5 relative">
                    <span className="absolute top-3 right-3 text-3xl font-mono font-black text-zinc-800">0{step.step}</span>
                    <h5 className="font-extrabold text-white text-sm tracking-wide">{step.title}</h5>
                    <p className="text-[11px] text-zinc-500 leading-relaxed">{step.description}</p>
                  </div>
                ))}
              </div>

              {/* Interactive verification client tester */}
              <div className="bg-zinc-950/40 p-5 rounded-2xl border border-white/5 space-y-4">
                
                <div>
                  <h4 className="font-bold text-white text-sm">Proximity System Connection Verify Checker</h4>
                  <p className="text-[11px] text-zinc-500 mt-0.5">Ensure your client mods are linked properly, type your exact Minecraft Username below to simulate connection UUID testing.</p>
                </div>

                <form onSubmit={handleVerifyName} className="flex flex-col sm:flex-row gap-3 max-w-lg">
                  <input 
                    type="text" 
                    required
                    placeholder="E.g. FitMC_Enthusiast"
                    value={verifyName}
                    onChange={(e) => setVerifyName(e.target.value.substring(0, 16))}
                    className="flex-grow bg-zinc-900/80 px-4 py-2.5 border border-white/5 text-xs text-zinc-200 rounded-xl focus:outline-none focus:border-yellow-500/50"
                  />
                  <button 
                    type="submit" 
                    className="px-6 py-2.5 bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-bold uppercase tracking-wider rounded-xl text-xs cursor-pointer"
                  >
                    Verify Client Mod link
                  </button>
                </form>

                {/* Status reporter response feedback */}
                {verifyStatus !== 'idle' && (
                  <div className={`p-4 rounded-xl border flex items-center gap-3 text-xs leading-relaxed ${
                    verifyStatus === 'testing' ? 'bg-zinc-900/60 border-zinc-800 text-zinc-300' :
                    verifyStatus === 'success' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' :
                    'bg-red-500/10 border-red-500/20 text-red-400'
                  }`}>
                    {verifyStatus === 'testing' && <div className="w-4 h-4 border-2 border-yellow-500 border-t-transparent rounded-full animate-spin" />}
                    {verifyStatus === 'success' && <Check className="w-5 h-5 text-emerald-400 shrink-0" />}
                    <span>{verifyStepText}</span>
                  </div>
                )}

              </div>

            </div>

            {/* Server commands FAQ list grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6">
              
              {/* Commands guide block */}
              <div className="bg-zinc-900/40 border border-white/5 rounded-2xl p-6 space-y-4">
                <h4 className="font-extrabold text-white text-base uppercase tracking-widest pl-1 border-l-2 border-yellow-500">Core Server Commands</h4>
                <p className="text-xs text-zinc-400">Type these standard commands inside your server chat input box once online:</p>
                
                <div className="space-y-2 font-mono text-xs">
                  <div className="flex justify-between p-2.5 bg-zinc-950/60 rounded-lg border border-white/5">
                    <span className="text-yellow-500 font-bold">/spawn</span>
                    <span className="text-zinc-400">Teleport back to main spawn hub</span>
                  </div>
                  <div className="flex justify-between p-2.5 bg-zinc-950/60 rounded-lg border border-white/5">
                    <span className="text-yellow-500 font-bold">/ah</span>
                    <span className="text-zinc-400">Open global player Auction House (SkyBlock)</span>
                  </div>
                  <div className="flex justify-between p-2.5 bg-zinc-950/60 rounded-lg border border-white/5">
                    <span className="text-yellow-500 font-bold">/v menu</span>
                    <span className="text-zinc-400">Triggers simple voice mod setting screen</span>
                  </div>
                  <div className="flex justify-between p-2.5 bg-zinc-950/60 rounded-lg border border-white/5">
                    <span className="text-yellow-500 font-bold">/sethome [name]</span>
                    <span className="text-zinc-400">Saves a personal warp coordinate coordinate</span>
                  </div>
                  <div className="flex justify-between p-2.5 bg-zinc-950/60 rounded-lg border border-white/5">
                    <span className="text-yellow-500 font-bold">/wings</span>
                    <span className="text-zinc-400">Open active cosmetic animation wings selectors</span>
                  </div>
                </div>
              </div>

              {/* FAQ Accordions blocks */}
              <div className="space-y-4">
                <h4 className="font-extrabold text-white text-base uppercase tracking-widest pl-1 border-l-2 border-yellow-500">Frequently Asked Questions</h4>
                
                <div className="bg-zinc-900/40 border border-white/5 rounded-xl p-4 text-xs">
                  <p className="font-bold text-white mb-1">Q: Does the voice mod work on other networks?</p>
                  <p className="text-zinc-400 leading-relaxed">A: Yes, simple voice mod jar is highly compatible, but our specific London proximity node configuration guarantees lag-free sound packet streaming.</p>
                </div>

                <div className="bg-zinc-900/40 border border-white/5 rounded-xl p-4 text-xs">
                  <p className="font-bold text-white mb-1">Q: Can I access Anarchy using standard Lunar Client?</p>
                  <p className="text-zinc-400 leading-relaxed">A: Absolutely! Enable simple voice mod options inside the Lunar client settings module before copying IP: {SERVER_IP}.</p>
                </div>

                <div className="bg-zinc-900/40 border border-white/5 rounded-xl p-4 text-xs">
                  <p className="font-bold text-white mb-1">Q: How do competitive tournament payouts operate?</p>
                  <p className="text-zinc-400 leading-relaxed">A: Every Saturday we tally ELO ranks or island net worth. The top 3 ranked players receive PayPal or crypto payouts directly.</p>
                </div>
              </div>

            </div>

          </div>
        )}

      </div>

      {/* FOOTER */}
      <footer className="mt-auto bg-zinc-950 border-t border-white/5 py-8 px-4 md:px-8 text-xs text-zinc-500">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          
          <div className="flex flex-col text-left">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-white font-black tracking-tight font-sans">FLEX-MC NETWORK</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-900 text-zinc-400 font-mono">v1.20</span>
            </div>
            <p className="max-w-md leading-relaxed text-[11px] text-zinc-500">
              Not an official Minecraft product. We are in no way affiliated with or endorsed by Mojang Synergies AB or Microsoft Corporation. Support store funds go directly towards backing premium hardware servers hosting fees.
            </p>
          </div>

          <div className="flex flex-wrap gap-6 text-[11px] font-semibold">
            <button onClick={() => navigateTo('wiki')} className="hover:text-white transition-colors cursor-pointer">GAME RULES</button>
            <button onClick={() => navigateTo('store')} className="hover:text-white transition-colors cursor-pointer">STORE T&C</button>
            <a href="https://discord.gg/SQPPFVtdxx" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">STAFF RECRUITMENT</a>
          </div>

          <p className="text-[11px]">© 2026 Flex-MC Network. Proudly hosted on dedicated fast European nodes.</p>

        </div>
      </footer>

      {/* SHOPPING CART OVERLAY MODAL */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-50 flex justify-end">
            
            {/* Backdrop click off */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />

            {/* Sliding Panel */}
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="relative w-full max-w-md h-full bg-[#0a0a0f] border-l border-white/10 p-6 shadow-2xl flex flex-col justify-between"
            >
              
              {/* Header */}
              <div>
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center gap-2">
                    <ShoppingCart className="w-5 h-5 text-yellow-500" />
                    <h3 className="font-extrabold text-white text-base uppercase tracking-wider">Shopping Basket</h3>
                  </div>
                  <button 
                    onClick={() => setIsCartOpen(false)}
                    className="p-1.5 bg-zinc-900 hover:bg-zinc-800 rounded-lg text-zinc-400 cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="h-[1px] bg-white/5 mb-4" />
              </div>

              {/* Steps views */}
              <div className="flex-grow overflow-y-auto pr-1">
                {checkoutStep === 'shopping' && (
                  <div className="space-y-4">
                    {cart.map((cartItem) => (
                      <div key={cartItem.item.id} className="p-3.5 bg-zinc-950 border border-white/5 rounded-xl flex items-center justify-between gap-4">
                        <div className="flex-grow text-left">
                          <h5 className="font-bold text-white text-xs leading-none">{cartItem.item.name}</h5>
                          <span className="text-[10px] text-yellow-500 font-mono font-bold block mt-1">€{cartItem.item.price.toFixed(2)} each</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => updateQuantity(cartItem.item.id, -1)}
                            className="w-6 h-6 bg-zinc-950 border border-white/5 rounded-md text-zinc-400 flex items-center justify-center font-bold text-xs hover:border-zinc-700 cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-mono font-bold text-white w-4 text-center">{cartItem.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(cartItem.item.id, 1)}
                            className="w-6 h-6 bg-zinc-950 border border-white/5 rounded-md text-zinc-400 flex items-center justify-center font-bold text-xs hover:border-zinc-700 cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>

                          <button 
                            onClick={() => removeFromCart(cartItem.item.id)}
                            className="p-1 text-zinc-600 hover:text-red-400 transition-colors ml-2 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}

                    {cart.length === 0 && (
                      <div className="py-20 text-center text-zinc-500 text-xs">
                        <ShoppingCart className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
                        <span>Your shopping cart basket is currently fully empty. Browse products inside Store page tab!</span>
                      </div>
                    )}
                  </div>
                )}

                {checkoutStep === 'processing' && (
                  <div className="py-24 text-center space-y-4">
                    <div className="w-12 h-12 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto" />
                    <div>
                      <h4 className="font-bold text-white text-sm uppercase">Securing Payment Gateway</h4>
                      <p className="text-xs text-zinc-500 mt-1 max-w-xs mx-auto">Initiating database synchronization logs. Handshaking user "{minecraftUsername}" UUID and verifying payment...</p>
                    </div>
                  </div>
                )}

                {checkoutStep === 'success' && (
                  <div className="py-16 text-center space-y-6">
                    <div className="w-16 h-16 bg-emerald-500/10 border border-emerald-500/30 rounded-full flex items-center justify-center mx-auto text-emerald-400 shadow-xl shadow-emerald-500/5">
                      <Check className="w-8 h-8 font-black stroke-[3px]" />
                    </div>
                    
                    <div>
                      <h4 className="font-extrabold text-white text-base uppercase">Checkout Successful!</h4>
                      <p className="text-xs text-zinc-400 mt-1.5 max-w-xs mx-auto leading-relaxed">
                        Secure transaction processed successfully for Minecraft Player <strong className="text-yellow-500 uppercase">{minecraftUsername}</strong>.
                      </p>
                    </div>

                    <div className="bg-zinc-950 p-4 rounded-xl border border-white/5 text-left text-xs font-mono space-y-1 my-2">
                      <span className="text-[10px] text-zinc-500 block uppercase font-bold tracking-wider mb-2">Claim Commands:</span>
                      <p className="text-zinc-300">1. Log inside Minecraft: <strong className="text-white">{SERVER_IP}</strong></p>
                      <p className="text-zinc-300">2. Run command line: <strong className="text-yellow-500">/claim</strong></p>
                      <p className="text-zinc-500 text-[10px] pt-1">Rank perks delivery takes between 2 to 5 minutes to fully reflect.</p>
                    </div>

                    <button 
                      onClick={() => {
                        setCheckoutStep('shopping');
                        setIsCartOpen(false);
                      }}
                      className="w-full py-3 bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-bold uppercase tracking-wider rounded-xl text-xs cursor-pointer"
                    >
                      Done & Close
                    </button>
                  </div>
                )}
              </div>

              {/* Checkout Form & Details (only if items present and step is normal) */}
              {cart.length > 0 && checkoutStep === 'shopping' && (
                <div className="border-t border-white/5 pt-4 mt-4 space-y-4">
                  
                  <div className="space-y-1.5 text-xs text-zinc-400">
                    <div className="flex justify-between">
                      <span>Subtotal items value:</span>
                      <span className="font-mono">€{cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-yellow-500 font-bold">
                      <span>Sales processing fees:</span>
                      <span>FREE</span>
                    </div>
                    <div className="h-[1px] bg-white/5 my-2" />
                    <div className="flex justify-between text-white text-sm font-black">
                      <span>Total balance amount:</span>
                      <span className="font-mono text-yellow-500">€{cartTotal.toFixed(2)}</span>
                    </div>
                  </div>

                  <form onSubmit={executeCheckout} className="space-y-3 text-left">
                    <div>
                      <label className="text-[10px] text-zinc-500 uppercase font-bold tracking-wider block mb-1">Minecraft Character Name</label>
                      <input 
                        type="text" 
                        required
                        placeholder="E.g. FitMC_Enthusiast"
                        value={minecraftUsername}
                        onChange={(e) => setMinecraftUsername(e.target.value.substring(0, 16))}
                        className="w-full bg-zinc-950 px-3 py-2.5 border border-white/5 focus:border-yellow-500/50 text-xs text-white rounded-xl focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-zinc-500 uppercase font-bold tracking-wider block mb-1">Checkout Payment Provider</label>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { id: 'card', name: 'Card' },
                          { id: 'paypal', name: 'PayPal' },
                          { id: 'crypto', name: 'BTC / Sol' },
                        ].map((p) => (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => setPaymentMethod(p.id as any)}
                            className={`py-2 border rounded-xl text-center text-xs font-semibold cursor-pointer whitespace-nowrap ${
                              paymentMethod === p.id 
                                ? 'bg-yellow-500/10 border-yellow-500 text-yellow-500' 
                                : 'bg-zinc-950 border-white/5 text-zinc-400 hover:border-zinc-800'
                            }`}
                          >
                            {p.name}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button 
                      type="submit"
                      className="w-full py-4 bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-black uppercase tracking-wider rounded-xl text-xs transition-colors flex items-center justify-center gap-2 mt-4 cursor-pointer"
                    >
                      <span>Execute Secure Checkout</span>
                      <Check className="w-4.5 h-4.5 stroke-[2.5px]" />
                    </button>
                  </form>

                </div>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* INDIVIDUAL NEWS DETAILED OVERLAY DRAWERS */}
      <AnimatePresence>
        {selectedNews && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedNews(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />

            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-2xl bg-[#0b0b0f] border border-white/10 rounded-2xl overflow-hidden shadow-2xl z-10 text-left max-h-[85vh] flex flex-col"
            >
              
              <div className="overflow-hidden h-56 relative bg-zinc-950 shrink-0">
                <img 
                  src={selectedNews.image} 
                  alt={selectedNews.title} 
                  className="w-full h-full object-cover opacity-60"
                />
                
                <div className="absolute top-4 left-4 px-2.5 py-1 rounded bg-zinc-950/90 text-xs font-bold text-yellow-500 tracking-wider uppercase">
                  {selectedNews.category}
                </div>

                <button 
                  onClick={() => setSelectedNews(null)}
                  className="absolute top-4 right-4 p-2 bg-zinc-900/90 hover:bg-zinc-800 rounded-lg text-zinc-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-6 md:p-8 overflow-y-auto space-y-4">
                
                <div className="flex items-center gap-3 text-xs text-zinc-500 font-mono">
                  <span>Published: {selectedNews.date}</span>
                  <span>•</span>
                  <span>Author: {selectedNews.author}</span>
                  <span>•</span>
                  <span>{selectedNews.readTime}</span>
                </div>

                <h3 className="text-2xl md:text-3xl font-black text-white leading-tight uppercase">
                  {selectedNews.title}
                </h3>

                <div className="h-[1px] bg-white/5 my-2" />

                <p className="text-zinc-300 text-sm leading-relaxed whitespace-pre-wrap">
                  {selectedNews.content}
                </p>

                {selectedNews.id === 'news-2' && (
                  <div className="bg-yellow-500/5 p-4 rounded-xl border border-yellow-500/20 text-xs text-yellow-500 flex gap-2.5">
                    <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                    <span>
                      Simple Voice mod installation triggers proximity chat immediately. Fabric users download it alongside normal utility loaders. Run UUID tests check from our WIKI tab.
                    </span>
                  </div>
                )}

              </div>

              <div className="p-4 bg-zinc-950 border-t border-white/5 text-right shrink-0">
                <button 
                  onClick={() => setSelectedNews(null)}
                  className="px-6 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-white font-bold text-xs uppercase rounded-xl border border-white/5 transition-all"
                >
                  Close article
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
