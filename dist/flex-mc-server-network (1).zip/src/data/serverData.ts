import { 
  ServerStatusInfo, 
  RuleInfo, 
  FeatureInfo, 
  RankPerk, 
  LeaderboardCollection, 
  StoreItem, 
  NewsArticle 
} from '../types';

export const SERVER_IP = 'Flex-MC.eu';

export const SERVERS_INFO: Record<string, ServerStatusInfo> = {
  anarchy: {
    id: 'anarchy',
    name: 'Anarchy Network',
    online: true,
    playersCount: 124,
    maxPlayers: 250,
    version: '1.20.4',
    ping: 23,
    description: 'No rules, no resets, hacks fully allowed. Survival in its rawest form. Features proximity voice chat for backstabs and diplomacy.',
    uptime: '99.9%',
    hardware: 'Ryzen 9 7950X / DDR5 / NVMe SSD',
    voicePluginRequired: true
  },
  skyblock: {
    id: 'skyblock',
    name: 'SkyBlock Realms',
    online: true,
    playersCount: 184,
    maxPlayers: 300,
    version: '1.20.4',
    ping: 18,
    description: 'Build your empire from a single island. Custom minions, dynamic physical stock market economy, islands leveling, and server-wide seasons.',
    uptime: '100.0%',
    hardware: 'Intel Core i9 14900K / Dedicated RAM',
    voicePluginRequired: false
  },
  pvp: {
    id: 'pvp',
    name: 'PvP Arenas & Practice',
    online: true,
    playersCount: 78,
    maxPlayers: 150,
    version: '1.8.9 - 1.20.4',
    ping: 12,
    description: 'Ultra responsive, click-optimized 1.8 sword hitreg and practice duels. Engage in custom 2v2 tournaments with crystal-clear voice chat tactics.',
    uptime: '99.8%',
    hardware: 'Custom High-Frequency Host London',
    voicePluginRequired: true
  }
};

export const RULES_DATA: Record<string, RuleInfo[]> = {
  anarchy: [
    { id: 'an-1', title: 'Intentional Server Lag Machines', description: 'Building chunk-loading lag devices, redstone clocks specifically designed to freeze tick-rates, or exploit crash-packets is strictly forbidden.', severity: 'high' },
    { id: 'an-2', title: 'Hacking & Cheats Permitted', description: 'Flight, X-Ray, Speed-Hacks, Killaura, and Baritone scripts are 100% allowed on of this mode. Enjoy the absolute raw code-combat.', severity: 'low' },
    { id: 'an-3', title: 'Griefing & Stealing Allowed', description: 'No base is safe. Stealing items, building lava casts, and blowing up towns is par for the course. Set coordinate traps wisely.', severity: 'low' }
  ],
  skyblock: [
    { id: 'sb-1', title: 'No Exploiting or Duping Items', description: 'Any form of material duplication, economy exploits, or inventory glitching will result in a permanent hardware ban and island wipes.', severity: 'high' },
    { id: 'sb-2', title: 'Insiding or Team Robbery', description: 'Inviting players into your Island Coop only to clear out chest inventories, steal spawners, and leave is strictly kick-bannable.', severity: 'high' },
    { id: 'sb-3', title: 'Automated Account Farming', description: 'Autoclicker scripts to bypass AFK pools, bot accounts, or script generators for item selling are not allowed.', severity: 'medium' }
  ],
  pvp: [
    { id: 'pvp-1', title: 'Modified Attack Clients & Scripts', description: 'Cheating softwares, reach extensions, double-clicking macros, auto block-hitting, or triggerbots will be caught by our custom Watchdog anticheat.', severity: 'high' },
    { id: 'pvp-2', title: 'Toxicity & Slurs in Matches', description: 'Aggressive slurs, real-life dox threats, or systemic harassment in public text display triggers instant manual shadow mutes.', severity: 'medium' },
    { id: 'pvp-3', title: 'Elo Boosting & Match Manipulation', description: 'Setting up secondary accounts or throwing games to boost ladder ranks will reset your seasonal ratings to zero.', severity: 'medium' }
  ]
};

export const FEATURES_DATA: Record<string, FeatureInfo[]> = {
  anarchy: [
    { title: 'No Map Resets', description: 'The outer overworld has been running continuously since launch. Explore rich server ruins spanning millions of blocks.', iconName: 'Compass' },
    { title: 'Lawless Society', description: 'No land claims, no moderators, no block protection. Form clans, build concealed vault systems, or rule spawn.', iconName: 'ShieldAlert' },
    { title: 'Simple Proximity Chat', description: 'Talk to players in 3D audio space directly. Hear them walk up, whisper strategy, or negotiate hostage swaps.', iconName: 'Mic' },
    { title: 'Custom Anti-Lag Engine', description: 'Maintains buttery smooth 20 TPS server speed even with hundreds of active flying hacked clients.', iconName: 'Cpu' }
  ],
  skyblock: [
    { title: 'Autonomic Minions', description: 'Deploy ore miners, auto-farmers, and collectors that work tirelessly even when you are fully offline.', iconName: 'UserRound' },
    { title: 'Dynamic Physical Market', description: 'Experience a live simulated stock ecosystem where item supply drastically affects local selling and buying margins.', iconName: 'TrendingUp' },
    { title: 'Custom Island Shields', description: 'Create dynamic layouts, customized portals, custom spawners, and security grids with team roles.', iconName: 'LayoutGrid' },
    { title: 'Seasonal Cash Rewards', description: 'Top three islands ranked by dynamic value receive hundreds of euros in store giftcards each month.', iconName: 'Coins' }
  ],
  pvp: [
    { title: 'Dueling Queue System', description: 'Instant matchmaking matches for Combo, NoDebuff, Sumo, BuildUHC, and Bridge. Climb our global ELO ladders.', iconName: 'Swords' },
    { title: 'Weekly Cash Tourneys', description: 'Showcase your skills in bracket tournaments on Saturday nights. Streamed live with professional commentary.', iconName: 'Trophy' },
    { title: 'Tactical Team Audio', description: 'Integrated proximity chat lets you call out target focal targets, direct flank setups, and scream in victory.', iconName: 'Volume2' },
    { title: '1.8 Perfect Hitreg', description: 'Custom network patch that strips latency delays, letting your block-hits, w-taps, and rods land flawlessly.', iconName: 'Zap' }
  ]
};

export const RANK_PERKS: Record<string, RankPerk[]> = {
  anarchy: [
    {
      name: 'CHAOS',
      price: '€14.99 / Lifetime',
      color: 'from-orange-500 to-red-600',
      multiplier: '1.2x Queue speed',
      perks: [
        'Bypass server crowded queues instantly',
        'Custom blood-red bold chat prefix [CHAOS]',
        'Toggle custom green/red glowing particle effects',
        'Command /color to cycle nickname presentation',
        'Keep inventory on accidental spawn-kill zones'
      ]
    },
    {
      name: 'DOOM',
      price: '€29.99 / Lifetime',
      color: 'from-purple-600 to-indigo-800',
      multiplier: 'Instant login pool',
      perks: [
        'Priority premium login block (never wait)',
        'Unlock unique death announcement styles that alert the chat',
        'Create up to 5 additional private home warps (/sethome)',
        'Custom obsidian dark chat prefix [DOOM]',
        'Immunity to standard anti-spam chat delay filters'
      ]
    }
  ],
  skyblock: [
    {
      name: 'ASTRAL',
      price: '€9.99 / Monthly',
      color: 'from-cyan-400 to-blue-600',
      multiplier: '+3 Minion capacity',
      perks: [
        'Increased active minion placement capacity',
        'Access to /fly command on your island claim',
        'Custom cyan chat prefix [ASTRAL]',
        'Weekly astral item crate package access',
        'Automatic ores smelting booster applied globally'
      ]
    },
    {
      name: 'TITAN',
      price: '€24.99 / Lifetime',
      color: 'from-yellow-500 to-amber-600',
      multiplier: 'Double island resource drop speed',
      perks: [
        'Automatic offline drop auto-sell hook',
        'Unlocks exclusive massive island template layouts',
        'Up to heavy +10 minion limit boost',
        'Complete titan equipment crate kit (/kit titan)',
        'Custom fiery gold bold prefix [TITAN] in main chat'
      ]
    }
  ],
  pvp: [
    {
      name: 'WARLORD',
      price: '€11.99 / Lifetime',
      color: 'from-red-500 to-rose-700',
      multiplier: '1.5x Elo gains on win lobbies',
      perks: [
        'Access to custom weapon sword skins & particle trails',
        '/nick command to customize your in-game scoreboard name',
        'Premium chat tag [WARLORD]',
        'Instant spectator access in high-tier active lobbies',
        'Access to exclusive lobby emotes'
      ]
    },
    {
      name: 'CHAMPION',
      price: '€34.99 / Lifetime',
      color: 'from-emerald-400 to-teal-600',
      multiplier: '2.0x Elo visual booster multiplier',
      perks: [
        'Premium registration slot in official weekly cash tournaments',
        'All exclusive cosmetic sword trails & glowing dynamic shields',
        'Unlocks unique game-winning particle bursts',
        'Full custom lobby custom cape and wings design tool',
        'Highest priority tag [CHAMPION]'
      ]
    }
  ]
};

export const LEADERBOARD_DATA: LeaderboardCollection = {
  anarchy: [
    { position: 1, username: 'FitMC_Enthusiast', skinSeed: '1', statValue: '4,210', extraStatLabel: 'Blocks Traveled', extraStatValue: '12.4M', tag: '💀 DOOM' },
    { position: 2, username: 'lavacast_enjoyer', skinSeed: '2', statValue: '2,950', extraStatLabel: 'Blocks Traveled', extraStatValue: '9.2M', tag: '🔥 CHAOS' },
    { position: 3, username: 'Gamer_Anarchy_99', skinSeed: '3', statValue: '1,820', extraStatLabel: 'Blocks Traveled', extraStatValue: '4.1M' },
    { position: 4, username: 'dupestation_x', skinSeed: '4', statValue: '1,720', extraStatLabel: 'Blocks Traveled', extraStatValue: '8.8M', tag: '🔥 CHAOS' },
    { position: 5, username: 'bed_bomber_07', skinSeed: '5', statValue: '1,104', extraStatLabel: 'Blocks Traveled', extraStatValue: '2.3M' }
  ],
  skyblock: [
    { position: 1, username: 'SkyRich_Premium', skinSeed: '6', statValue: 'Level 14,820', extraStatLabel: 'Net Worth', extraStatValue: '$148.2M', tag: '✨ TITAN' },
    { position: 2, username: 'DrSeedPlanter', skinSeed: '7', statValue: 'Level 11,290', extraStatLabel: 'Net Worth', extraStatValue: '$120.4M', tag: '🌌 ASTRAL' },
    { position: 3, username: 'MinionOverlord', skinSeed: '8', statValue: 'Level 9,840', extraStatLabel: 'Net Worth', extraStatValue: '$98.1M', tag: '✨ TITAN' },
    { position: 4, username: 'SpawnerStacker_Pro', skinSeed: '9', statValue: 'Level 7,120', extraStatLabel: 'Net Worth', extraStatValue: '$64.9M' },
    { position: 5, username: 'FlexMCMaster_1', skinSeed: '10', statValue: 'Level 5,420', extraStatLabel: 'Net Worth', extraStatValue: '$41.2M' }
  ],
  pvp: [
    { position: 1, username: 'drag_click_god', skinSeed: '11', statValue: '2,840 ELO', extraStatLabel: 'Win Streak', extraStatValue: '42 wins', tag: '🏆 CHAMP' },
    { position: 2, username: 'W_Tap_Mechanic', skinSeed: '12', statValue: '2,510 ELO', extraStatLabel: 'Win Streak', extraStatValue: '31 wins', tag: '🩸 WARLORD' },
    { position: 3, username: 'CpsMonster', skinSeed: '13', statValue: '2,320 ELO', extraStatLabel: 'Win Streak', extraStatValue: '14 wins', tag: '🩸 WARLORD' },
    { position: 4, username: 'RodSpammerPrime', skinSeed: '14', statValue: '2,110 ELO', extraStatLabel: 'Win Streak', extraStatValue: '9 wins' },
    { position: 5, username: 'Lava_Bucket_Pro', skinSeed: '15', statValue: '1,980 ELO', extraStatLabel: 'Win Streak', extraStatValue: '18 wins' }
  ]
};

export const STORE_ITEMS: StoreItem[] = [
  // Ranks
  { id: 'rank-doom', name: 'DOOM Rank [Anarchy]', price: 29.99, originalPrice: 39.99, category: 'ranks', description: 'Be the ultimate champion of the Anarchy Realm.', features: ['Bypass crowded logic queue lines instantly', 'Unique server-announce alert when logging in', 'Apply up to 5 additional private homing warps', 'Custom chat color tags and exclusive bold dark obsidian signifier'], badge: '70% Off', color: 'purple' },
  { id: 'rank-titan', name: 'TITAN Rank [SkyBlock]', price: 24.99, category: 'ranks', description: 'Rule the sky island realm with automated farming support.', features: ['Automatic offline drop auto-sell tool enabled', 'Increase active minion placements to +10 max size', 'Epic full Titan equipment chest kit (/kit titan)', 'Custom glowing golden bold name shield in global server listing'], badge: 'Popular', color: 'gold' },
  { id: 'rank-champion', name: 'CHAMPION Rank [PvP]', price: 34.99, originalPrice: 49.99, category: 'ranks', description: 'The absolute tier for competitive practice arena gods.', features: ['Guaranteed priority lobby slot in official Saturday cash tourneys', 'Unlock all premium cosmetic trial packs and animated shields', 'Custom name tags formatting and high-tier lobby cape styling tool', 'Double daily rewards and automatic 2x Elo gain multiplier display value'], badge: 'Elite', color: 'emerald' },
  
  // Keys & Crates
  { id: 'key-anarchy', name: '3x Doomsday Spawn Keys', price: 4.99, category: 'keys', description: 'Key chest bundle to redeem for random powerful tier loot.', features: ['Loot can contain packed obsidian, stacked bedrock tools', 'Random blast weapon tools up to Enchantment Level VI', '15% chance for a permanent queue upgrade boost ticket'], badge: 'Value', color: 'rose' },
  { id: 'key-skyblock', name: '5x Astral Treasure Keys', price: 7.49, originalPrice: 9.99, category: 'keys', description: 'Unbox powerful spawner stacks and netherite components on island.', features: ['Unboxes customized robotic helpers, iron-golem spawners', 'Special dynamic boosters that speed up local crop cycles', 'Chance to drop direct island cash vouchers'], badge: 'Sale', color: 'cyan' },
  { id: 'key-pvp', name: '10x Warlord Cosmetic Keys', price: 5.99, category: 'keys', description: 'Unleash marvelous cosmetic effects for lobby styling.', features: ['Exclusive kill animations (lightning strike, rainbow fireworks)', '3D animated sword trails matching block color values', 'Unique lobby entry sound sounds (ender dragon roar, ghast cry)'], color: 'indigo' },

  // Boosters
  { id: 'boost-network', name: 'Global 2x Network Booster (3 Hours)', price: 9.99, category: 'boosters', description: 'Activate server-wide 2x booster rewards for all players, securing huge community support ratings.', features: ['Applies a massive 2x SkyBlock money multiplier to everyone', 'Boosts PvP Practice Elo reward values for 3 solid hours', 'Broadcasting custom chat thank-you to your Minecraft screen name'], badge: 'Community', color: 'amber' },
  { id: 'boost-island', name: 'SkyBlock Triple Island Harvest (1 Hour)', price: 3.99, category: 'boosters', description: 'Boosts your specific personal SkyBlock island activity speeds.', features: ['Triples minion crop and mining speed rates instantly', 'Gives high-chance for premium gem discoveries', 'Allows private lobby teleport configurations'], color: 'blue' },

  // Cosmetics
  { id: 'cos-cape', name: 'Animated Flex-MC Wings Pack', price: 12.99, category: 'cosmetics', description: 'Look magnificent in the PvP Practice lobbies and Hub.', features: ['3 unique options: Crimson Angel, Cyber Drone, Holo butterfly', 'Compatible across 1.8.9 and 1.20 and client plugins', 'Toggle visibility using standard in-game command `/wings`'], badge: 'Epic', color: 'pink' },
  { id: 'cos-kill', name: 'Meteor Strike Kill Effect', price: 6.49, category: 'cosmetics', description: 'Crush the opposition with stylistic celestial fire.', features: ['Summons a mini fiery meteor explosion when defeating PvP opponents', 'Plays a custom low-frequency high impact bass drop sound', 'Configurable visual splash radius size options through `/effects`'], color: 'orange' }
];

export const NEWS_ARTICLES: NewsArticle[] = [
  {
    id: 'news-1',
    title: 'To Be Announced',
    excerpt: 'Our completely overhauled SkyBlock Realm launches this Saturday. Discover all-new automations, minion capabilities, and the live Stock Market.',
    content: 'We are thrilled to present our most ambitious SkyBlock update yet! Season 4 introducing the Stock Market where item values self-adjust based on player transactions. We also added full co-op island capabilities, security permission interfaces, and a €500 monthly pool for leaderboard champions. Prepare your farming schemes, build factories, and align minion arrays – server starts Saturday 6:00 PM CET!',
    date: 'TBA',
    author: 'Admin_Flex',
    category: 'Update',
    readTime: '3 min read',
    image: 'https://images.unsplash.com/photo-1605899435973-ca2d1a8861cf?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'news-2',
    title: 'To Be Announced',
    excerpt: 'Critical voice mod instructions to help you install the proximity voice engine required for tactical PvP and brutal Anarchy communication.',
    content: 'Communication is key to survival. To deliver an immersive immersive experience, Flex-MC has integrated the Simple Voice Connection system. If you want proximity-sound tactical dueling and backstabs, listen up: you need to download simple-voice-chat plugin from curseforge/modrinth, place the mod jar in your .minecraft/mods folder, specify port config in Minecraft settings if needed, and configure mute/deafen bind keys. We show an interactive guide below!',
    date: 'TBA',
    author: 'Mod_Proximity',
    category: 'System',
    readTime: '4 min read',
    image: 'https://images.unsplash.com/photo-1590608897129-79da98d15969?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'news-3',
    title: 'To Be Announced',
    excerpt: 'Anarchy coordinates have leaked. A long-forgotten base holding hundreds of diamond blocks has been unsealed near coordinates -14000, 24000.',
    content: 'In true lawless fashion, database audits have recovered static logs containing active coordinate maps to an epic underground fortress built in 2024. Reportedly stacked with bedrock tools, double chest shulkers, and diamond blocks, players are already converging at -14000, 24000 for a server-scale resource battle. Proximity voice chat is highly advised if you plan on assembling instant tactical factions.',
    date: 'TBA',
    author: 'Gamer_Anarchy_99',
    category: 'Event',
    readTime: '2 min read',
    image: 'https://images.unsplash.com/photo-1627856013091-fed6e4e30025?auto=format&fit=crop&q=80&w=800'
  }
];

export const VOICE_CHAT_GUIDE = [
  {
    step: 1,
    title: 'Install Client-Side Mod',
    description: 'Download the standard "Simple Voice Chat" mod matching version 1.20.4 (or 1.8.9 for PvP) from CurseForge, Modrinth or the official Fabric/Forge pages.'
  },
  {
    step: 2,
    title: 'Drag into Mod Folder',
    description: 'Place the downloaded .jar mod file directly inside your local ".minecraft/mods" or setup launcher path (CurseForge Launcher, Lunar Client, Modrinth App have auto-toggle switches).'
  },
  {
    step: 3,
    title: 'Launch Minecraft & Join',
    description: `Open the game and type server IP: "${SERVER_IP}" to join any server lobby. The audio server connects automatically in background!`
  },
  {
    step: 4,
    title: 'Configure Keys',
    description: 'Once inside, press "V" to trigger the voice settings menu. Here you can configure microphone calibration, individual volumes, test mic feedback, and bind customized Push-to-Talk or mute keys.'
  }
];

export const MOCK_CHAT_POOL = [
  { username: 'LavaCaster_X', message: 'Who wants to form a clan on spawn in Anarchy?', prefix: '[CHAOS]', prefixColor: 'text-orange-500' },
  { username: 'Fitz_YT', message: 'Buying spawner sets at /ah on SkyBlock! Good prices.', prefix: '[ASTRAL]', prefixColor: 'text-cyan-400' },
  { username: 'MinecraftDad_99', message: 'The voice audio proximity mod works perfectly under London hosting node, crisp sound.', prefix: '', prefixColor: 'text-slate-400' },
  { username: 'PvPElo_Master', message: 'Unboxed a meteor strike kill effect on practicing lobby, literally crazy.', prefix: '[CHAMPION]', prefixColor: 'text-emerald-400' },
  { username: 'Mod_Proximity', message: 'Remember to join Discord channels of Flex-MC to find voice mod comrades!', prefix: '[MOD]', prefixColor: 'text-red-500' },
  { username: 'CpsMonster', message: 'Warlord cape cosmetics look slick with active dragon skin trails.', prefix: '[WARLORD]', prefixColor: 'text-rose-500' },
  { username: 'FitMC_Enthusiast', message: 'Coords -14k, 24k is a warzone right now, proximity audio is just pure memes.', prefix: '[DOOM]', prefixColor: 'text-purple-500' },
  { username: 'SkyRich_Premium', message: 'Minion setups got huge speed upgrades on season 4, already lvl 200.', prefix: '[TITAN]', prefixColor: 'text-yellow-500' }
];
